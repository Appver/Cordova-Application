/*Created by Karthick*/
/*Learning Circle Factory*/

 /*LC title*/
module.factory('lcTitle', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getLcTitle: function(data) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/lctitle', data);
    }
  }
}]);

/*Home page*/
module.factory('lcHome', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getLcHome: function(data) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/lchome', data);
    }
  }
}]);

/*Assignment function*/
module.factory('lcassignment', ['$http', function($http) {
	$http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
	return {
		getassignment : function(data) {
			return $http.post('http://test.classle.in/newclassle/learningcircle/lcassign', data);
		}
	}
}])

module.factory('lcassignmentsearch', ['$http', function($http) {
	$http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
	return {
		getLcAssignSearch : function(data) {
			return $http.post('http://test.classle.in/newclassle/learningcircle/lcassignsearch', data);
		}
	}
}])

module.factory('lcassignmentsort', ['$http', function($http) {
	$http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
	return {
		getLcAssignSort : function(data) {
			return $http.post('http://test.classle.in/newclassle/learningcircle/lcassignsort', data);
		}
	}
}])

/*Bookmark page*/
module.factory('learningCircleBook', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getLcBook: function(data) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/lcbookmark', data);
    }
  }
}]);

/*Bookmark search page*/
module.factory('learningCircleBookSearch', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getLcBookSearch: function(param) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/lcbookmarksearch', param);
    }
  }
}]);

/*Bookmark content search page*/
module.factory('learningCircleBookcontent', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getLcBookContent: function(param) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/lcbookmarkcontent', param);
    }
  }
}]);

/*Disscusion page*/
module.factory('lcForum', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getLcForum: function(data) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/lcforum', data);
    }
  }
}]);
/*Disscusion search page*/
module.factory('lcForumSearch', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getLcForumSearch: function(param) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/lcforumssearch', param);
    }
  }
}]);
/*Disscusion sort page*/
module.factory('lcForumSort', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getLcForumSort: function(param) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/lcforumsort', param);
    }
  }
}]);

/*MemberShip page*/
module.factory('lcMember', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getLcMember: function(data) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/lcmember', data);
    }
  }
}]);

/*invite member*/
module.factory('lcSuggest', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getsuggestMember: function(data) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/lcsuggestowner', data);
    }
  }
}]);

/*Leave LC*/
module.factory('leavelc', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    leaveRequest: function(data) {
      return $http.post('http://test.classle.in/newclassle/content/unsubscribe', data);
    }
  }
}]);

/*Request owner LC*/
module.factory('requestownerlc', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    requestOwner: function(data) {
      return $http.post('http://test.classle.in/newclassle/learningcircle/assignowner', data);
    }
  }
}]);

/*
 * All Learning Circle
 */
module.factory('onlinealllc', ['$http', function($http) {
  return {
    onlinealllcDetails: function(data) {
      $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
      return $http.post('http://test.classle.in/newclassle/lclanding/alllc', data);
    }
  }
}]);

/*
 * All Learning Circle Search
 * lclanding api
 * lcappfactory
 */
module.factory('onlinealllcsearch', ['$http', function($http) {
  return {
    onlinealllcsearchDetails: function(data) {
			$http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
      return $http.post('http://test.classle.in/newclassle/lclanding/alllcsearch', data);
    }
  }
}]);


/*
 * my Learning Circle
 */
module.factory('onlinemylc', ['$http', function($http) {
  return {
    onlinemylcDetails: function(data) {
      $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
      return $http.post('http://test.classle.in/newclassle/lclanding/mylc', data);
    }
  }
}]);
/*
 * my Learning circle ob subscribe
 */
module.factory('onlinesubscribe', ['$http', function($http) {
  return {
    onlinesubscribeDetails: function(data) {
    alert(data);
      $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
      return $http.post('http://test.classle.in/newclassle/lclanding/ogsubscribe', data);
    }
  }
}]);