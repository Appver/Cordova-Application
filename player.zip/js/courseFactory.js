var ROOT_PATH_API = "http://test.classle.in";
/*
 * Course info
 */
module.factory('courseAboutFactory', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getInfo: function(nid) {
      var d = 'node=' + nid;
      return $http.post(ROOT_PATH_API+'/course+/courseplus/courses/info', d);
    },

    addCart: function(nid, payment_type) {
      var d = 'node=' + nid + '&paymenttype=' + payment_type;
      return $http.post(ROOT_PATH_API+'/course+/courseplus/courses/cart', d);
    }
  }
}]);

/*
 * Course announcements
 */
module.factory('courseAnnouncements', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getAnnouncements: function(nid) {
      var limit = '';
      var d = 'type=announcement&limit=' + limit + '&nid=' + nid;
      return $http.post(ROOT_PATH_API+'/course+/courseplus/myclassle/course', d);
    }
  }
}]);

/*
 * Course Assignment
 */
module.factory('courseAssignment', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getCourseAssignment: function(nid) {
      var limit = '';
      var d = 'type=assignment&limit=' + limit + '&nid=' + nid;
      return $http.post(ROOT_PATH_API+'/course+/courseplus/myclassle/course', d);
    }
  }
}]);



/*
 * Course Circles
 */
module.factory('courseCircles', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getCourseCircles: function(nid, sortsvalue, searchstring) {
      var limit = '';
      var d = 'type=coursecircles&limit=' + limit + '&nid=' + nid + '&sortsvalue=' + sortsvalue + '&searchstring=' + searchstring;
      return $http.post(ROOT_PATH_API + '/course+/courseplus/myclassle/course', d);
    }
  }
}]);


/*
 * Course Ask
 */
module.factory('courseAsk', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getCourseAsk: function(nid,asks, searchstring) {
      var limit = '';
      var d = 'type=ask&limit=' + limit + '&nid=' + nid + '&sortsvalue=' + asks + '&searchstring=' + searchstring;
      return $http.post(ROOT_PATH_API + '/course+/courseplus/myclassle/course', d);
    }
  }
}]);

/*
 * Course Resources
 */
module.factory('courseResources', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getCourseResources: function(nid, pagetypes, searchstring) {
      var limit = '';
      var d = 'type=resources&limit=' + limit + '&nid=' + nid + '&sortsvalue=' + pagetypes + '&searchstring=' + searchstring;;
      return $http.post(ROOT_PATH_API + '/course+/courseplus/myclassle/course', d);
    }
  }
}]);

/*
 * Course Sync
 */
module.factory('courseSync', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getCourseSync: function() {
      var d = 'type=sync&limit=5';
      return $http.post(ROOT_PATH_API + '/course+/courseplus/myclassle/course', d);
    }
  }
}]);

/*
 * Course modules
 */
module.factory('courseModules', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    getCourseModules: function(nid) {
      var limit = '';
      var d = 'type=modules&limit=' + limit + '&nid=' + nid;
      return $http.post(ROOT_PATH_API + '/course+/courseplus/myclassle/course', d);
    }
  }
}]);


/*
 * Current course
 */

module.factory('UserCoursesList', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    userCourses: function(type) {
      var d = 'types=' + type;
      return $http.post(ROOT_PATH_API + '/newclassle/index/chq', d);
    }
  }
}]);
/*
 * Quiz question
 */
module.factory('quizQuestionsFactory',['$http', function($http){
	$http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
	return {
		quizAllQuestions: function(d) {
			return $http.post(ROOT_PATH_API + '/course+/courseplus/quizpage/quizquestions',d);
		}
	}
}]);
/*
 * Quiz Answer
 */
module.factory('quizAnswersFactory',['$http', function($http){
	$http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
	return {
		quizAllAnswers: function(getanswers) {
		var d = { selectedchoices : getanswers};
			return $http.post(ROOT_PATH_API + '/course+/courseplus/quizpage/quizresults',d,{headers: { 'Content-Type': 'application/json'}});
		}
	}
}]);
/*
 * mycourses sync
 */
module.factory('mycoursessync',['$http', function($http){
	$http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
	return {
		mycoursessyncDetails: function(contentnid, path) {
			var data = 'node='+contentnid+'&path='+path;
			return $http.post(ROOT_PATH_API + '/course+/courseplus/slate/resource', data);
		}
	}
}]);

