var app = angular.module('demoApp', []);
app.controller('videoCtrl', ['$scope', '$sce', function($scope, $sce) {
	var url = 'file:///mnt/sdcard/a/clip.mp4';
//var url = 'clip.mp4';
	var cuepoint = true;
	if(cuepoint)
		var data_cuepoint = "data-cuepoints=[5, 8, 15, 20]";
	else
		var data_cuepoint = '';
	$scope.videoUrl = $sce.trustAsHtml('<div class="player" data-embed="false" data-ratio="0.4167" '+data_cuepoint+' id="player"><video><source type="video/mp4" src="'+url+'"></video></div>');
}]);
