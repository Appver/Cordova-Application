var module = angular.module("classleApp", ['ngRoute','toaster','mobile-angular-ui','ui.bootstrap']);

var basePath = '/mnt/sdcard/com.classle.angular/';
module.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
            when('/home', {
                templateUrl: 'signup.html',
            }).
            when('/myclassle', {
                templateUrl: 'header.html',
            }).
            otherwise({
                redirectTo: '/home'
            });
    }]); 

module.run(function($rootScope, $location , classleConnect, classleDatabase){
    $rootScope.$on("$routeChangeStart" ,function(event, next, current) {
        classleConnect.get('session').success(function(response) {
            $rootScope.user = response;
            if(response.uid) {
                alert('mani');
                alert(basePath);
                classleDatabase.dbOpen({name:'userdb', path:basePath}, function(data) {
                    alert(data);
                }, function(data) {
                    alert(data);
                });
            }
        }).error(function(response) {
            alert("Error");
        });
    });
});


module.controller("authController", ['$scope', 'classleConnect', '$location', 'toaster','classleDatabase',function($scope, classleConnect, $location, toaster,classleDatabase) {
    $scope.doLogin = function(mail, password) {
        mail = 'mani kandan';
        password = '82246258';
       if(mail == undefined || password == undefined || mail.length < 1 || password.length < 1) {
            alert("Email and Password is required.");
       }else {
           var param = 'username=' + mail + '&password=' +password;
           classleConnect.post('user/login', param).success(function(response) {
                classleConnect.get('session').success(function(response) {
                    alert('mani');
                    /*classleDatabase.dbOpen({name:'userdb', path:basePath}, function(data) {
                        alert(data);
                    }, function(data) {
                        alert(data);
                    });*/
                }).error(function(response) {
                    
                });
                //$location.path('/myclassle');
           }).error(function(response) {
                toaster.pop('error', null, response[0], null, 'trustedHtml');
           });
       }
    }
    
    $scope.social = function(provider) {
        alert(provider);
    }
    
    $scope.doRegister = function(fname, lname, mail, pwd, tac) {
        if(fname == undefined || fname == '') {
            toaster.pop('error' , null, 'First name is required.');
            return false;
        }
        if(lname == undefined || lname == '') {
            toaster.pop('error', null,"LastName is required.");
            return false;
        }
        if(mail == undefined || mail == '') {
            toaster.pop('error', null,"E-mail is required.");
            return false;
        }
        if(pwd == undefined || pwd == '') {
            toaster.pop('error', null,"LastName is required.");
            return false;
        }
        if(tac == undefined || tac != true) {
            toaster.pop('error', null,"Please accept the terms and conditions.");
            return false;
        }
        if(pwd.length < 4) {
            toaster.pop('error', null, "Password is required minimum four char.");
        }
        var object = 'name=' + mail + '&profile_firstname=' + fname + '&profile_lastname=' + lname + '&pass=' + pwd + '&mail=' + mail + '&legal_accept=' + tac + '&source=fromSlate&captcha_response=' + this.captcha_response;
        classleConnect.post('classleUser/register', object).success(function(response) {
            toaster.pop('success', null, "Registration success. Please check your mail for further instruction.", null, 'trustedHtml');
        }).error(function(response) {
            toaster.pop('error', null, response[0], null, 'trustedHtml');
        });    
    }

}]);
  
  

