'use strict';
module.factory('classleConnect', ['$http', '$q','$rootScope','cordovaReady','$window',function($http, $q,$rootScope,cordovaReady,$window) {
    $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
    var serviceEndpoint = 'http://test.classle.in/';
    var method = {};
    method.get = function(endpoint) {
        return $http.get(serviceEndpoint + 'api/' + endpoint);   
    };
    method.post = function(endpoint, object,headers) {
        return $http.post(serviceEndpoint + endpoint, object, headers); 
    };
    method.getlocaldata = cordovaReady(function(dbargs, onSuccess, onError) {
        ClassleSqlite.DatabaseRawQuery(dbargs, function () {
        var that = this,
          args = arguments;

        if (onSuccess) {
          $rootScope.$apply(function () {
            onSuccess.apply(that, args);
          });
        }
      }, function () {
        var that = this,
          args = arguments;

        if (onError) {
          $rootScope.$apply(function () {
            onError.apply(that, args);
          });
        }
      });
    });
    method.openDB = cordovaReady(function(dbArg, onSuccess, onError) {
        ClassleSqlite.openDatabase(dbArg, function () {
        var that = this,
          args = arguments;

        if (onSuccess) {
          $rootScope.$apply(function () {
            onSuccess.apply(that, args);
          });
        }
      }, function () {
        var that = this,
          args = arguments;

        if (onError) {
          $rootScope.$apply(function () {
            onError.apply(that, args);
          });
        }
      });
    });
    method.loadLocalData = cordovaReady(function(dbArg, onSuccess, onError) {
        ClassleSqlite.SqliteTransaction(dbArg, function () {
        var that = this,
          args = arguments;

        if (onSuccess) {
          $rootScope.$apply(function () {
            onSuccess.apply(that, args);
          });
        }
      }, function () {
        var that = this,
          args = arguments;

        if (onError) {
          $rootScope.$apply(function () {
            onError.apply(that, args);
          });
        }
      });
    });
    method.getDbPath = cordovaReady(function(dbname, onSuccess, onError) {
        ClassleSqlite.getDatabasePath(dbname, function () {
            var that = this,
              args = arguments;

            if (onSuccess) {
              $rootScope.$apply(function () {
                onSuccess.apply(that, args);
              });
            }
            }, function () {
            var that = this,
              args = arguments;

            if (onError) {
              $rootScope.$apply(function () {
                onError.apply(that, args);
              });
            }
        });
    });
		method.deleteDatabase = cordovaReady(function(dbName, Path, onSuccess, onError) {
			ClassleSqlite.deleteDatabase(dbName, Path, function() {
					var that = this, args = arguments;
					if(onSuccess) {
						$rootScope.$apply(function() {
							onSuccess.apply(that, args);
						});
					}
				}, function() {
					var that = this, args = arguments;
					if(onError) {
						$rootScope.$apply(function() {
							onError.apply(that, args);
						});
					}
			});
		});
    method.getnetworkState = cordovaReady(function(onSuccess, onError) {
       ClassleNetwork.network.type(function () {
        var that = this,
          args = arguments;

        if (onSuccess) {
          $rootScope.$apply(function () {
            onSuccess.apply(that, args);
          });
        }
      }, function () {
        var that = this,
          args = arguments;

        if (onError) {
          $rootScope.$apply(function () {
            onError.apply(that, args);
          });
        }
      });  
    });
    method.getmountlist = cordovaReady(function(onSuccess, onError) {
        mountlist.mountevent(function () {
        var that = this,
          args = arguments;

        if (onSuccess) {
          $rootScope.$apply(function () {
            onSuccess.apply(that, args);
          });
        }
      }, function () {
        var that = this,
          args = arguments;

        if (onError) {
          $rootScope.$apply(function () {
            onError.apply(that, args);
          });
        }
      });
    });
    method.getAppProperty = cordovaReady(function(key, onSuccess, onError) {
        ClassleProperties.getClassleProperty(key, function () {
        var that = this,
          args = arguments;

        if (onSuccess) {
          $rootScope.$apply(function () {
            onSuccess.apply(that, args);
          });
        }
      }, function () {
        var that = this,
          args = arguments;

        if (onError) {
          $rootScope.$apply(function () {
            onError.apply(that, args);
          });
        }
      });
    });
    method.setAppProperty = cordovaReady(function(key, value, onSuccess, onError) {
        ClassleProperties.setClassleProperty(key, value,function () {
        var that = this,
          args = arguments;

        if (onSuccess) {
          $rootScope.$apply(function () {
            onSuccess.apply(that, args);
          });
        }
      }, function () {
        var that = this,
          args = arguments;

        if (onError) {
          $rootScope.$apply(function () {
            onError.apply(that, args);
          });
        }
      });
    });
    method.OptionDialogs = cordovaReady(function(message,onSuccess, title, buttonlables, option) {
        
        navigator.notification.option(
            message,
            function () {
                var that = this,
                  args = arguments;

                if (onSuccess) {
                  $rootScope.$apply(function () {
                    onSuccess.apply(that, args);
                  });
                }
            },
            title,
            buttonlables,
            option
	   );
    });
    method.checkFilestatus = cordovaReady(function(path,fileName,onSuccess, onError) {
       var directory = "file://" + path + fileName;
       $window.resolveLocalFileSystemURL(directory, function () {
        var that = this,
          args = arguments;

        if (onSuccess) {
          $rootScope.$apply(function () {
            onSuccess.apply(that, args);
          });
        }
      }, function () {
        var that = this,
          args = arguments;

        if (onError) {
          $rootScope.$apply(function () {
            onError.apply(that, args);
          });
        }
      });
    });
    method.copyDirs = cordovaReady(function(sourcePath,destFile,onSuccess, onError) {

       ClassleFileUtils.copy(sourcePath, destFile, function () {
        var that = this,
          args = arguments;

        if (onSuccess) {
          $rootScope.$apply(function () {
            onSuccess.apply(that, args);
          });
        }
      }, function () {
        var that = this,
          args = arguments;

        if (onError) {
          $rootScope.$apply(function () {
            onError.apply(that, args);
          });
        }
      });
    });
    method.webIntent = cordovaReady(function(filepath, ext, onSuccess, onError) {
        window.plugins.webintent.startActivity({
                action: window.plugins.webintent.ACTION_VIEW,
                url: filepath,
                type: ext
            },
            function() {
                var that = this,args = arguments;
                if(onSuccess) {
                    $rootScope.$apply(function() {
                        onSuccess.apply(that, args);
                    });
                }
            },function() {
                var that = this, args = arguments;
                if(onError) {
                    $rootScope.$apply(function() {
                        onError.apply(that, args);
                    });
                }
            }
        );
    });
    return method;
}]);
