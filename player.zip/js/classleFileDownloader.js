'use strict';

module.factory('fileDownloadCtrl', ['classleConnect', '$cordovaFileTransfer', '$cordovaFile','toaster', function(classleConnect, $cordovaFileTransfer, $cordovaFile, toaster) {
  return {
      downloadFile: function() {
          var query = "SELECT * FROM download WHERE status = 0";
          var downParam = {'name':'classledb', 'path':'default','tableName':'download','query':query};
          classleConnect.getlocaldata(downParam, function(dSuccess) {
              var data = dSuccess.row;
              var nids = [];
              var filepatharray = [];
              var filenameArray = [];
              for(var i=0; i < data.length; i++) {
                  var fileUrl = data[i].filepath;
                  var nid = data[i].nid;
                  nids[i] = nid;
                  var fileName = data[i].filename;
                  filenameArray[i] = fileName;
                  if((fileUrl.lastIndexOf("youtube") < 0) && (fileUrl.length > 1)) {
                      var datadir = cordova.file.externalRootDirectory;
                      var filePath = datadir + "com.classle.classlemobile/files/";
                      filePath = filePath + data[i].filename;
                      filepatharray[i] = filePath;
                      var url = data[i].filepath;
                      document.addEventListener("deviceready", function() {
                          $cordovaFileTransfer.download(url,filePath,{},true).then(function(success){
                              var pidx = filepatharray.indexOf(decodeURIComponent(success.nativeURL));  
                              var iNid = nids[pidx];
                              var iFileName = filenameArray[pidx];
                              var qry = "UPDATE download SET status = 1, devicepath = '"+success.nativeURL+"' WHERE nid="+iNid+" AND filename = '"+iFileName+"'";
                              var suParam = {'name':'classledb', 'path':'default','query':qry};
                              classleConnect.loadLocalData(suParam, function(data) {                
                              }, function(data) {
                                  toaster.pop('error', 'Download error. Please restart you app and connect your device with internet');
                              });
                          }, function(error) {
                              toaster.pop('error', 'Download error. Please restart you app and connect your device with internet');
                          });
                      });
                  }else {
                      var qry = "UPDATE download SET status = 1 WHERE nid="+nid+" AND filename = '"+fileName+"'";
                      var suParam = {'name':'classledb', 'path':'default','tableName':'download','query':qry};
                      classleConnect.loadLocalData(suParam, function(data) {}, function(data) {});
                  }
              }
          }, function(dError) {
              alert(JSON.stringify(dError));
          });
      }
  }
}]);
