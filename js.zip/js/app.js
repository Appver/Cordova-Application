var module = angular.module("classleApp", ['ngRoute','toaster','mobile-angular-ui','ui.bootstrap', 'ngCordovaOauth', 'ngCordova']);

var basefolder = '/com.classle.classlemobile/';
module.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
            when('/home', {
                templateUrl: 'signup.html',
            }).
            when('twitter-form', {
                templateUrl: 'files/twitter-form.html',
            }).
            when('/myclassle', {
                templateUrl: 'myclassle.html',
            }).
            when('/myclassle1', {
                templateUrl:'myclassle-offline.html',     
            }).
            when('/library', {
                templateUrl: 'library.html',
            }).
            when('/view/:nid', {
                templateUrl: 'library-content.html',
            }).
            when('/alllc', {
                templateUrl: 'files/lc-online.html',
            }).
            when('/aboutlc', {
                templateUrl: 'files/lc-about.html',
            }).
            when('/mylc', {
                templateUrl: 'files/mylc-online.html',
            }).
            when('/lchome/:nid', {
                templateUrl: 'files/lc-home.html',
            }).
            when('/lcbookmark/:nid', {
                templateUrl: 'files/lc-bookmark.html',
            }).
            when('/lcassignment/:nid', {
                templateUrl: 'files/lc-assignment.html',
            }).
            when('/lcforum/:nid', {
                templateUrl: 'files/lc-forum.html',
            }).
            when('/lcmembers/:nid', {
                templateUrl: 'files/lc-members.html',
            }).
            when('/promos', {
                templateUrl: 'course-listing.html',
            }).
            when('/flip/:nid/:flipnid', {
                templateUrl: 'flip.html',
            }).
            when('/allcourse', {
                templateUrl: 'files/catalogue-all-courses.html',
            }).
            when('/mycourse', {
                templateUrl: 'files/catalogue-my-courses.html',
            }).
            when('/private', {
                templateUrl: 'files/catalogue-private.html',
            }).
            when('/about', {
                templateUrl: 'files/catalogue-about.html',
            }).
			when('/course-info/:nid', {
                templateUrl: 'files/course-info.html',
            }).
            when('/announcement/:nid', {
                templateUrl: 'files/course-announcement.html',
            }).
            when('/modules/:nid', {
                templateUrl: 'files/course-module.html',
            }).
            when('/assignment/:nid', {
                templateUrl: 'files/course-assignment.html',
            }).
            when('/circles/:nid', {
                templateUrl: 'files/course-circles.html',
            }).
            when('/ask-an-expert/:nid', {
                templateUrl: 'files/course-ask.html',
            }).
            when('/resources/:nid', {
                templateUrl: 'files/course-resource.html',
            }).
            when('/quiz/:qnid/:nid', {
                templateUrl: 'files/module-page.html',
            }).
            when('/module/:mid/quiz/:qid', {
                templateUrl: 'files/module-inside-offline.html',
            }).
            otherwise({
                redirectTo: '/home'
            });
    }]); 

module.run(function($rootScope, $location, classleConnect, fileDownloadCtrl,$cordovaDialogs,$cordovaToast){
    
    $rootScope.Offline_login = function() {
       /* classleConnect.getmountlist(
            function(list){

                var s = list;
                var n = s.split("\n");
                var storage = [];
                var disp = [];
                var i;
                for (i = 0; i < n.length; i++) {
                    var line = n[i].toString();
                    if(line.search("nodev") > 0 && line.search("nosuid") > 0 && (line.search("/mnt/") > 0 || line.search("/storage/") > 0) && line.search("asec") == -1 && line.search("_rw") == -1 && line.search("shell") == -1 && line.search("tmpfs") == -1 ) {
                        var memory = line.split(" ");
                        var zerocut = memory[1].split("/");
                        var cnt_zero = zerocut.length -1;
                        //if(zerocut[cnt_zero] != 0) {
                        disp.push((memory[1].toString()).replace("/mnt","").replace("/storage","").replace("/emulated","").replace("/","").toUpperCase());
                        storage.push(memory[1]);
                        //}
                    }
                }
                var title=disp.filter(function(itm,i,disp) {
                  return i==disp.indexOf(itm);
                });

                var path =storage.filter(function(itm,i,storage) {
                  return i==storage.indexOf(itm);
                });

                function success(results) {
                    if(results.buttonIndex == 1)
                        alert(path[results.option]);
                    else
                        navigator.app.exitApp();
                }

                navigator.notification.option(
                    'Choose a storage to load the learning resource for you',
                    success,
                    'Alert',
                    ['Ok','Exit'],
                    title
                );
            }, function(error) { 
                alert(JSON.stringify(error));
            });*/
        var q = "SELECT * FROM user";
        var path = 'default';
        var p = {'name':'userdb','path':path,'query':q,'tableName':'user'};
        classleConnect.getlocaldata(p, function(response) {

            if(response.row != null && response.row[0].uid > 0 && $location.path() == '/home'){
                $rootScope.user = JSON.parse(response.row[0].session);
                $location.path('/myclassle'); 
            }
        }, function(response) {
            $rootScope.toast("Something went wrong! Please try again later");
        });
    };
    $rootScope.checkNetwork = function() {
        classleConnect.getnetworkState(function(response) {
            if(response != 'none') 
                $rootScope.networkStatus = true;
            else
                $rootScope.networkStatus = false;
            if($rootScope.networkStatus) {
                
                classleConnect.get('session').success(function(response) {
                    if(response.uid && $location.path() == '/home') {
                        $rootScope.user = response;
                        screen.unlockOrientation();
                        $location.path('/myclassle');
                        fileDownloadCtrl.downloadFile();
                    }
                    screen.unlockOrientation();
                }).error(function(response) {
                    $rootScope.toast("Something went wrong! Please try again later");
                });
            } else {
                screen.unlockOrientation();
                $cordovaDialogs.confirm('You are not connected to the internet! Do you like to login in offline mode?', 'Not connected to internet', ['Go','Cancel & Exit'])
                .then(function(buttonIndex) {
                    var btnIndex = buttonIndex;
                    if(btnIndex == 1) {
                        $rootScope.Offline_login();   
                    }else {
                        navigator.app.exitApp();
                    }
                
                });
            }
        }, function(error) {
            $rootScope.networkStatus = false;
        });
    }
    $rootScope.checkNetwork();
    
    $rootScope.$on("$routeChangeStart" ,function(event, next, current) {
        classleConnect.getnetworkState(function(response) {
            if(response != 'none') 
                $rootScope.networkStatus = true;
            else
                $rootScope.networkStatus = false;
            if($rootScope.networkStatus) {
                classleConnect.get('session').success(function(response) {
                    if(response.uid && $location.path() == '/home') {
                        $rootScope.user = response;
                        $location.path('/myclassle');
                    }else {
                        event.preventDefault();
                        return;
                    }
                }).error(function(response) {
                    $rootScope.toast("Something went wrong! Please try again later");
                });
            }/*else {

                var q = "SELECT uid FROM user";
                var path = 'default';
                var p = {'name':'userdb','path':path,'query':q,'tableName':'user'};
                classleConnect.getlocaldata(p, function(response) {
                    if(response.row != null && response.row[0].uid > 0 && $location.path() == '/home'){ 
                        $location.path('/myclassle');
                    }else {
                        event.preventDefault();
                        return;
                    }
                }, function(response) {
                    alert(JSON.stringify(response));
                });
            }*/
        }, function(error) {
            $rootScope.networkStatus = false;
        });
    });
    
    $rootScope.toast = function(message) {
        $cordovaToast.show(message, 'short', 'bottom').then(function(success){}, function(errror){});
    }
});


module.controller("authController", ['$scope', 'classleConnect', '$location', 'toaster','$route','$cordovaOauth','$cordovaFileTransfer','$http','$cordovaOauthUtility','$rootScope',function($scope, classleConnect, $location, toaster, $route,$cordovaOauth,$cordovaFileTransfer,http,$cordovaOauthUtility,$rootScope) {

    $scope.doLogin = function(mail, password) {
       if(mail == undefined || password == undefined || mail.length < 1 || password.length < 1) {
            $rootScope.toast("Email and Password is required.");
       }else {
           var param = 'username=' + mail + '&password=' +password;
           classleConnect.post('newclassle/user/login', param).success(function(lgresponse) {
                classleConnect.get('session').success(function(response) {
                    if(response.uid) {
                       $scope.putUserdata(response); 
                    }

                }).error(function(sessionerror) {
                    $rootScope.toast('Something went wrong! Please try again later!');
                });
           }).error(function(response) {
               var response1 = JSON.stringify(response);
               if(response1.indexOf("username") > 0)
                    $rootScope.toast("Wrong username or password.");
               else
                    $rootScope.toast('Something went wrong! Please try again later!');
           });
       }
    }
    
    $scope.putUserdata = function(response) {
        var db = [];
        db.name = 'userdb';
        db.path = 'default';
        classleConnect.openDB(db, function(data) {
            var userdata = [];
            userdata.query = 'CREATE TABLE IF NOT EXISTS user (uid int(11), session TEXT) ';
            userdata.name = 'userdb';
            userdata.path = "default";
            classleConnect.loadLocalData(userdata, function(data) {
                userdata.query = "INSERT INTO user VALUES(" + response.uid +",'"+ JSON.stringify(response)+"')";
                classleConnect.loadLocalData(userdata, function(querydata) {
                    var d = response.picture
                    var opt = {};
                    var db1 = [];
                    db1.path = "default";
                    db1.name = 'classledb';
                    classleConnect.openDB(db1, function(data) {
                        var content = [];
                        content.query = '';
                        content.name = 'classledb';
                        content.path = "default";
                        var tables = ['CREATE TABLE IF NOT EXISTS download(nid INTEGER, filename TEXT, filepath TEXT, devicepath TEXT, root TEXT, ltn TEXT, status INTEGER DEFAULT 0)','CREATE TABLE IF NOT EXISTS courses (gid INTEGER, name TEXT, language TEXT, start_date INT(11), end_date INT(11), author VARCHAR(200), subject VARCHAR(200), filepath VARCHAR(200),sync_status INTEGER)','CREATE TABLE IF NOT EXISTS course_resource (gid INTEGER, nid INTEGER, quiz_id INTEGER, name TEXT, type TEXT, rname TEXT, language TEXT, parent INTEGER)','CREATE TABLE IF NOT EXISTS quiz (quiz_id INTEGER, name TEXT, language TEXT)','CREATE TABLE IF NOT EXISTS questions (qid INTEGER, quiz_id INTEGER, question TEXT, qtype TEXT, options TEXT, correct_opt INTEGER, attempts INTEGER, current_choice INTEGER,langugage TEXT,cuepoint INTEGER)','CREATE TABLE IF NOT EXISTS course_module (gid INTEGER, nid INTEGER, title TEXT)'];
                        for(var i=0; i< tables.length; i++) {
                            content.query = tables[i];
                            classleConnect.loadLocalData(content, function(success){
                                if(tables.length == i) {
                                    $route.reload();
                                    $rootScope.toast('Login successful');
                                }
                            }, function(error){
                                alert(JSON.stringify(error));
                                $rootScope.toast('Something went wrong! Please try again later!');    
                            });
                        }
                    }, function(data){ 
                        alert(JSON.stringify(data));
                        $rootScope.toast('Something went wrong! Please try again later!');
                    });
                    
                } , function(querydata) {
                    $rootScope.toast('Something went wrong! Please try again later!');
                });
            }, function(data) {
                $rootScope.toast('Something went wrong! Please try again later!');
            });
        }, function(data) {
            $rootScope.toast('Something went wrong! Please try again later!');
        });   
    }
    
    $scope.social = function(provider) {
        if(!$rootScope.networkStatus) {
            $rootScope.toast('Please connect your device with internet!!');
            return;
        }
        switch(provider) {
            case 'facebook':
                $cordovaOauth.facebook("1552344255034784", ["email"]).then(function(result) {
                    http.get('https://graph.facebook.com/me?access_token='+ result.access_token).then(function(data) {
                        var reqparam = {provider:'facebook', data:data};
                        var headers = {"headers": {'Content-Type' : 'application/json'}};
                        classleConnect.post('api/slate/auth', reqparam,headers).success(function(result) {
                            classleConnect.get('session').success(function(response) {
                                $scope.putUserdata(response);
                            }).error(function(response) {
                                $rootScope.toast('Something went wrong! Please try again later!');
                            });
                        }).error(function(result) {
                            $rootScope.toast('Something went wrong! Please try again later!');
                        });
                    },function(data) {
                        $rootScope.toast('Something went wrong! Please try again later!');
                    });
                },function(result) {
                   $rootScope.toast('Something went wrong! Please try again later!');
                });
                break;
            case 'google':
                $cordovaOauth.google("22169648155-5qn02lbp61b15afc9gemm6278eusdtpn.apps.googleusercontent.com", ["https://www.googleapis.com/auth/plus.login", "email","profile","https://www.googleapis.com/auth/plus.profile.emails.read"]).then(function(result) {
                    http.get('https://www.googleapis.com/oauth2/v1/userinfo?access_token='+ result.access_token).then(function(data) {
                        var reqparam = {provider:'google', data:data};
                        var headers = {"headers": {'Content-Type' : 'application/json'}};
                        classleConnect.post('api/slate/auth', reqparam,headers).success(function(result) {
                            classleConnect.get('session').success(function(response) {
                                $scope.putUserdata(response);
                            }).error(function(sessionerror) {
                                $rootScope.toast('Something went wrong! Please try again later!');
                            });
                        }).error(function(result) {
                            $rootScope.toast('Something went wrong! Please try again later!');
                        });
                    },function(data) {
                        $rootScope.toast('Something went wrong! Please try again later!');
                    });
                }, function(result) {
                    $rootScope.toast('Something went wrong! Please try again later!');
                });
                break;
            case 'twitter':
                /*var clientid = '9mrLGSekYIocYI5AJbKCSyATu';
                var secret = 'OXiEF9nEwk49LJgmGEWjSm0CGqLWc924zqrXnK2W0CTJjqEXYN';
                $cordovaOauth.twitter(clientid, secret).then(function(data) {
                   alert(data.oauth_token);
                    //var header = $cordovaOauth.twitterauthHeader(clientid,secret,data.oauth_token);
                    var oauthObject = {
                        //realm: "http://api.twitter.com/",
                        oauth_consumer_key: clientid,
                        oauth_nonce: $cordovaOauthUtility.createNonce(10),
                        oauth_signature_method: "HMAC-SHA1",
                        oauth_timestamp: Math.round((new Date()).getTime() / 1000.0),
                        oauth_version: "1.0",
                        oauth_token:data.oauth_token
                     };
                    var signatureObj = $cordovaOauthUtility.createSignature("POST", "https://api.twitter.com/1.1/account/verify_credentials.json", oauthObject, {},secret);
                    http.post('https://api.twitter.com/1.1/account/verify_credentials.json',{
    headers: {'Authorization': signatureObj.authorization_header}}).then(function(result) {
                        alert(JSON.stringify(result));
                    },function(result) {
                        alert(JSON.stringify(result));
                    });
                }, function(data) {
                    alert(JSON.stringify(data));
                });*/
                if(window.cordova) {
                    var cordovaMetaData = cordova.require('cordova/plugin_list').metadata;
                    if(cordovaMetaData.hasOwnProperty('org.apache.cordova.inappbrowser') === true) {
                        var twitterauth = window.open('http://classle.net/classleauth/twitter','_blank', 'location=no,clearsessioncache=yes,clearcache=yes');
                        twitterauth.addEventListener('loadstart', function(event) {
                            if(event.url === 'https://www.classle.net/' ) {
                                twitterauth.close();
                                classleConnect.get('session').success(function(response) {
                                    alert(response.uid);
                                    if(response.uid)
                                        $scope.putUserdata(response);
                                }).error(function(sessionerror) {
                                    $rootScope.toast('Something went wrong! Please try again later!');
                                });
                            }
                        });
                    }
                } 
                break;
            case 'yahoo':
                $cordovaOauth.yahoo('dj0yJmk9YWxvSHlyNXA2TVAyJmQ9WVdrOVNHSktjVnBRTm1VbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD0wNA--','475ca4283428e3ed83237fa2657ab7201182c883','http://test.classle.in').then(function(result) {
                    var userURL = 'http://social.yahooapis.com/v1/user/';
                    var Key = 'dj0yJmk9YWxvSHlyNXA2TVAyJmQ9WVdrOVNHSktjVnBRTm1VbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD0wNA--'
                    var once = $cordovaOauthUtility.createNonce(6);
                    var timeStamp = Math.round((new Date()).getTime() / 1000.0);
                    var oauthObject = {
                        oauth_consumer_key: Key,
                        oauth_nonce: $cordovaOauthUtility.createNonce(10),
                        oauth_signature_method: "HMAC-SHA1",
                        oauth_timestamp: Math.round((new Date()).getTime() / 1000.0),
                        oauth_version: "1.0",
                        oauth_token:result.access_token
                    };
                    
                    var signatureObj = $cordovaOauthUtility.createSignature("POST", userURL, oauthObject,{}, '475ca4283428e3ed83237fa2657ab7201182c883');
                    
                    http.defaults.headers.post.Authorization = signatureObj.authorization_header;
                    
                    http.post(userURL+result.oauth_yahoo_guid+'/profile?format=json').success(function(response) {
                        alert(JSON.stringify(response));
                    }).error(function(response) {
                        $rootScope.toast('Something went wrong! Please try again later!');
                    });
                    
                },function(result) {
                    $rootScope.toast('Something went wrong! Please try again later!');
                });
                break;
            case 'linkedin':
                $cordovaOauth.linkedin('78plwprf5mhj3a','enJ892Yzb2FcXuCd',["r_basicprofile","r_fullprofile","r_emailaddress","r_contactinfo"]).then(function(data) {
                    http.get('https://api.linkedin.com/v1/people/~:(id,first-name,last-name,maiden-name,formatted-name,public-profile-url,picture-url,email-address,date-of-birth,phone-numbers,languages)?oauth2_access_token='+data.access_token).then(function(result) {
                        var reqparam = {provider:'linkedin', data:result};
                        var headers = {"headers": {'Content-Type' : 'application/json'}};
                        classleConnect.post('api/slate/auth', reqparam,headers).success(function(result) {
                            classleConnect.get('session').success(function(response) {
                                $scope.putUserdata(response);
                            }).error(function(response) {
                                $rootScope.toast('Something went wrong! Please try again later!');
                            });      
                        }).error(function(result) {
                            $rootScope.toast('Something went wrong! Please try again later!');
                        });
                    },function(result) {
                        $rootScope.toast('Something went wrong! Please try again later!');
                    });
                        
                }, function(data) {
                    $rootScope.toast('Something went wrong! Please try again later!');
                });
                break;
            case 'windows':
                $cordovaOauth.windows('000000004C136F6E',["wl.basic","wl.birthday","wl.emails","wl.phone_numbers","wl.photos","wl.postal_addresses","wl.contacts_birthday","wl.contacts_photos"], 'Ja7bDy75BZdVV-IvuXzv9I9S2uNk1fMG','http://test.classle.in/classleauth/windows').then(function(data) {
                    http.get('https://apis.live.net/v5.0/me?access_token='+data.access_token).then(function(result) {
                        var reqparam = {provider:'linkedin', data:result};
                        var headers = {"headers": {'Content-Type' : 'application/json'}};
                        classleConnect.post('api/slate/auth',reqparam, headers).success(function(result) {
                            classleConnect.get('session').success(function(response) {
                                $scope.putUserdata(response);
                            })
                    },function(response) {
                        $rootScope.toast('Something went wrong! Please try again later!');
                    });
                },function(data) {
                    $rootScope.toast('Something went wrong! Please try again later!');
                });
                }, function(data) {
                   $rootScope.toast('Something went wrong! Please try again later!');
                });
                break;
            default:
                break;
        }
    }
    
    $scope.doRegister = function(fname, lname, mail, pwd, tac) {
         if(!$rootScope.networkStatus) {
            $rootScope.toast('Please connect your device with internet!!');
            return;
        }
        if(fname == undefined || fname == '') {
            $rootScope.toast('First name is required.');
            return false;
        }
        if(lname == undefined || lname == '') {
            $rootScope.toast("LastName is required.");
            return false;
        }
        if(mail == undefined || mail == '') {
            $rootScope.toast("E-mail is required.");
            return false;
        }
        if(pwd == undefined || pwd == '') {
            $rootScope.toast("LastName is required.");
            return false;
        }
        if(tac == undefined || tac != true) {
            $rootScope.toast("Please accept the terms and conditions.");
            return false;
        }
        if(pwd.length < 4) {
            $rootScope.toast("Password is required minimum four char.");
        }
        var object = 'name=' + mail + '&profile_firstname=' + fname + '&profile_lastname=' + lname + '&pass=' + pwd + '&mail=' + mail + '&legal_accept=' + tac + '&source=fromSlate&captcha_response=' + this.captcha_response;
        classleConnect.post('api/classleUser/register', object).success(function(response) {
            $rootScope.toast("Registration success. Please check your mail for further instruction.");
        }).error(function(response) {
            $rootScope.toast(response[0]);
        });    
    }

}]);
  
module.controller("profileHeader" , ["$scope",  "classleConnect", '$rootScope',function($scope, classleConnect, $rootScope) {
    if(!$rootScope.networkStatus)
        return;
    classleConnect.get('session').success(function(response) {
        $scope.data = response;
    }).error(function(response) {
       $rootScope.toast('Something went wrong! Please try again later!');
    });
}]);
  
/*module.controller("myCourseCtrl" , ["$scope", "classleConnect", "$rootScope",function($scope, classleConnect,$rootScope) {
    if(!$rootScope.networkStatus)
        return;
    var courseParam = "limit=5&type=course";
    classleConnect.post('course+/courseplus/myclassle/mycontent',courseParam).success(function(response) {
        $scope.viewcontent = true;
        if(response.length < 1 ) {
            $scope.viewcontent = false;
        }
        $scope.data = response;
    }).error(function(response) {
        toaster.pop('error', null, JSON.stringify(response), null, 'trustedHtml');
    });
}]);*/
 module.controller("myCourseCtrl" , ["$scope", "classleConnect", "$rootScope",function($scope, classleConnect, $rootScope) {
    var courseParam = "type=course&limit=10";
    var name = 'classledb'; 
    var path = 'default';
    var tableName = 'courses';
    var query = 'SELECT gid FROM courses';
    var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
    classleConnect.getlocaldata(dbarray, function(data){
     $scope.nids = data;

   classleConnect.post('course+/courseplus/mycourse/mycontents',courseParam).success(function(response) {     
     var dbnids = new Array();
      if($scope.nids.row != null){
     		for(var i =0; i< $scope.nids.row.length;i++){
     			dbnids[i] = $scope.nids.row[i].gid;
    	 }
     }
     else{
     	dbnids[0] = 0;
     }
     
     $scope.viewcontent = true;
     if(response.length < 1 ) {
         $scope.viewcontent = false;
      }
      $scope.response = response;
      $scope.syncBtn = '';
    	var name = 'classledb'; 
        var path = 'default';
        var tableName = 'courses';
        var query;
    	for(var i=0;i<response.length;i++){
    		var nums = parseInt(response[i].nid);
    		if(dbnids.indexOf(nums) == -1){
                query = "insert into courses (gid,name,language,start_date,end_date,author,sync_status) values("+response[i].nid+",'"+response[i].title+"','english',"+response[i].start_date+","+response[i].end_date+",'"+response[i].author+"',"+response[i].sync_status+")";
		  		var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		  		classleConnect.loadLocalData(dbarray, function(data){
		  			//alert(JSON.stringify(data));
		  		},
		  		function (data){
                    $rootScope.toast('Something went wrong! Please try again later!');
		  		});
    		}
    	}
    	for(var j=0;j<response.length;j++){
    		var downnums = parseInt(response[j].nid);
    		if(dbnids.indexOf(downnums) == -1){
		  		 query = "insert into download (nid,filename,filepath, status) values("+response[j].nid+",'"+response[j].imgname+"','"+response[j].imgpath+"', 0)";
		  		 var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		  		 classleConnect.loadLocalData(dbarray, function(data){
		  			 //alert(JSON.stringify(data));
		  		 },
		  		function (data){
                     $rootScope.toast('Something went wrong! Please try again later!');
		  		});
    		}
    	}
    }).error(function(response) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
    
   }, function (data){
        $rootScope.toast('Something went wrong! Please try again later!');
   });
    
}]);

module.controller("myClassleSlider", ["$scope", "classleConnect", "$rootScope",function($scope, classleConnect, $rootScope) {
    if(!$rootScope.networkStatus)
        return;
    var largeParam = 'limit=5&size=large';
    classleConnect.post('course+/courseplus/myclassle/slider',largeParam).success(function(response) {
        $scope.viewcontent = true;
        if(response.length < 1 ) {
            $scope.viewcontent = false;
        }
        $scope.courses = response;
    }).error(function(response) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
    
    var smallParam = 'limit=5&size=small'; 
    classleConnect.post('course+/courseplus/myclassle/slider',smallParam).success(function(response) {
        $scope.viewcontent = true;
        if(response.length < 1 ) {
            $scope.viewcontent = false;
        }
        $scope.coursessmall = response;
    }).error(function(response) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
}]);

module.controller("myLcCtrl", ["$scope", "classleConnect", "$rootScope",function($scope, classleConnect, $rootScope) {
    if(!$rootScope.networkStatus)
        return;
    var lcparam = 'limit=5&type=lc';
    classleConnect.post('newclassle/myclassle/mycontent', lcparam).success(function(response) {
        $scope.viewcontent = true;
        if(response.length < 1 ) {
            $scope.viewcontent = false;
        }
        $scope.data = response;
    }).error(function(response) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
}]);

module.controller("myBookmoarkCtrl" , ["$scope", "classleConnect", "$rootScope",function($scope, classleConnect, $rootScope) {
    if(!$rootScope.networkStatus) 
        return;
    var bookparam = 'type=bookmark&limit=5';
    classleConnect.post('newclassle/myclassle/mycontent', bookparam).success(function(response) {
        $scope.viewcontent = true;
        if(response.length < 1 ) {
            $scope.viewcontent = false;
        }
        $scope.data = response;
        
    }).error(function(response) {
       $rootScope.toast('Something went wrong! Please try again later!');
    });
}]);

module.controller('myCourseofflineCtrl', ['$scope', '$rootScope','classleConnect',function($scope, $rootScope,classleConnect) {
    if($rootScope.networkStatus) 
        return;
    var db = [];
    db.name = 'classledb';
    db.path = 'default';
    db.query = "SELECT c.*, d.devicepath FROM courses c LEFT JOIN download d ON c.gid = d.nid";
    db.tableName = 'contents';
    classleConnect.getlocaldata(db,function(data) {
       $scope.data = data.row;
    }, function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });

}]);

module.controller('myLcofflineCtrl', ['$scope', '$rootScope','classleConnect',function($scope, $rootScope, classleConnect) {
    if($rootScope.networkStatus) 
        return;
    var db = [];
    db.name = 'clssledb';
    db.path = 'default';
    db.query = "SELECT * FROM contents WHERE type = 'lc'";
    db.tableName = 'contents';
    classleConnect.getlocaldata(db,function(data) {
       $scope.data = data.row;
       for(var i = 0;i < $scope.data.length; i++) {
           $scope.data[i].data = JSON.parse($scope.data[i].data);
       }
    }, function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
}]);

module.controller('myBookmarkofflineCtrl', ['$scope', 'classleConnect', '$rootScope',function($scope, classleConnect,$rootScope) {
    if($rootScope.networkStatus) 
        return;
    var db = [];
    db.name = 'classledb';
    db.path = 'default';
    db.query = "SELECT * FROM contents WHERE type = 'bookmark'";
    db.tableName = 'contents';
    ClassleSqlite.DatabaseRawQuery(db,function(data) {
       $scope.data = data.row;
       for(var i = 0;i < $scope.data.length; i++) {
           $scope.data[i].data = JSON.parse($scope.data[i].data);
       }
    }, function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
    
   /* classleConnect.getlocaldata(db).success(function(data) {
       $scope.data = data.row;
       for(var i = 0;i < $scope.data.length; i++) {
           $scope.data[i].data = JSON.parse($scope.data[i].data);
       }
    }).error(function(data) {
        alert(JSON.stringify(data));
    });*/
}]);
module.controller('eventheaderCtrl', ['$scope', 'classleConnect', '$sce','$rootScope',function($scope, classleConnect, $sce,$rootScope) {
    if(!$rootScope.networkStatus)
        return;
    classleConnect.post('newclassle/librarycon/eventheader').success(function(response) {
        for(var i=0; i< response.length; i++) {
            response[i] = $sce.trustAsHtml(response[i]);
        }
        $scope.response = response;
                             
    }).error(function(response) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
}]);
module.controller('profileHeaderOnlineCtrl', ['$scope','classleConnect','$rootScope', function($scope, classleConnect,$rootScope) {
    if(!$rootScope.networkStatus)
        return;
    classleConnect.post('newclassle/librarycon/profileheader', '').success(function(response) {
        //alert(JSON.stringify(response));
        $scope.info = response;
    }).error(function(response) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
}]);

module.controller('profileHeaderOfflineCtrl', ['$scope', 'classleConnect','$rootScope', function($scope, classleConnect,$rootScope) {
    if($rootScope.networkStatus)
        return;
    var db = [];
    db.name = 'userdb';
    db.path = 'default';
    db.query = "SELECT session FROM user limit 1";
    db.tableName = 'user';
    ClassleSqlite.DatabaseRawQuery(db,function(data) {
        $scope.data = JSON.parse(data.row[0].session);
    }, function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
    
}]);

module.controller('libraryonlineCtrl', ['$scope', 'classleConnect', '$rootScope','$cordovaFile', function($scope, classleConnect, $rootScope, $cordovaFile) {
   
  $scope.searchtype;
  var limit = 0;    
  $scope.spinner = true;
  var api ='newclassle/librarypage/librarysearchresult';
  $scope.doSearch = function(searchtext) { 
      $scope.search = searchtext;
      $scope.spinner = true;
      $scope.searchdata = '';
      classleConnect.post(api, 'limit='+limit+'&searchkeyword='+searchtext).success(function(response) {
        $scope.searchdata = response;
        $scope.pagecount = response.pagecount;
        $scope.spinner = false
      }).error(function(response) {
        $rootScope.toast('Something went wrong! Please try again later!');
      });
  }
  $scope.doSearch('classle');
    $scope.changePage = function() {
        $scope.spinner = true;
        limit = $scope.currentPage;
        classleConnect.post(api, 'limit='+limit+'&searchkeyword='+$scope.search).success(function(data) {
          $scope.searchdata = data;
          $scope.spinner = false;
        }).error(function(data) {
          $rootScope.toast('Something went wrong! Please try again later!');
        });
    }
    
  $scope.sync = function(nid) {
      /*$scope.basePath = '';
      classleConnect.getAppProperty("basePath", function(data){
          if(data == null) {
            classleConnect.getmountlist(function(data) {
                var s = data;
                var n = s.split("\n");
                var storage = [];
                var disp = [];
                var i;
                for (i = 0; i < n.length; i++) {
                    var line = n[i].toString();
                    if(line.search("nodev") > 0 && line.search("nosuid") > 0 && (line.search("/mnt/") > 0 || line.search("/storage/") > 0) && line.search("asec") == -1 && line.search("_rw") == -1 && line.search("shell") == -1 && line.search("tmpfs") == -1 ) {
                        var memory = line.split(" ");
                        var zerocut = memory[1].split("/");
                        var cnt_zero = zerocut.length -1;
                        //if(zerocut[cnt_zero] != 0) {
                        disp.push((memory[1].toString()).replace("/mnt","").replace("/storage","").replace("/emulated","").replace("/","").toUpperCase());
                        storage.push(memory[1]);
                        //}
                    }
                }
                var title=disp.filter(function(itm,i,disp) {
                  return i==disp.indexOf(itm);
                });

                var path =storage.filter(function(itm,i,storage) {
                  return i==storage.indexOf(itm);
                });

                classleConnect.OptionDialogs(
                    'Choose a storage to load the learning resource for you',
                     function success(results) {
                        if(results.buttonIndex == 1) {
                            var base = path[results.option];
                            classleConnect.setAppProperty('basePath', base, function(data) {
                                if(data == 'Success') {
                                    $scope.basePath = base;
                                    var sourceFile = $scope.basePath + basefolder +"db/";
                                    classleConnect.checkFilestatus(sourceFile,"userdb",function(data){
                                        if(data.isFile === true) {
                                           $scope.processSync($scope.basePath, nid);
                                        }else if(data.code) {
                                            classleConnect.getDbPath('userdb', function(data) {
                                                alert(JSON.stringify(data));
                                                alert(1);
                                            }, function(data) {
                                                alert(JSON.stringify(data));
                                            });
                                        }
                                    }, function(data) {
                                        classleConnect.getDbPath('userdb', function(data) {
                                            var dbfile = data.path;
                                            var sourcePath = 'file://'+dbfile.replace('userdb','');
                                            alert(sourcePath);
                                            sourceFile = 'file://'+sourceFile;
                                            document.addEventListener("deviceready", function () {
                                                $cordovaFile.copyFile(sourcePath,'userdb',sourceFile)
                                                .then(function(success) {
                                                    alert(JSON.stringify(success));
                                                }, function(error) {
                                                    alert(JSON.stringify(error));
                                                });
                                            });
                                        }, function(data) {
                                            alert(JSON.stringify(data));
                                        });
                                    });

                                }
                            }, function(data) {
                                toaster.pop('error', null, "Something went wrong, Please try again.");
                            });
                        }
                        else
                            toaster.pop('error', null, "Sync not performed, Please try again.");
                    },
                    'Alert',
                    ['Ok','Exit'],
                    title
                );
            }, function(data) {
                toaster.pop('error', null, "Something went wrong, Please try again.");
            });
          }else {
            $scope.basePath = data;
            var sourceFile = $scope.basePath + basefolder +"db/";
            classleConnect.checkFilestatus(sourceFile, "classledb", function(data) {
                if(data.isFile === true) {
                   $scope.processSync($scope.basePath, nid);
                }
            }, function(data) {
                alert(JSON.stringify(data));
                alert('error');
            });
          }
                                        
      }, function(data) {
          toaster.pop('error', null, "Something went wrong, Please try again.");
      });*/
      $scope.processSync('default', nid);
  }
  
  $scope.processSync = function(basePath, nid) {
    var api = 'api/slate/synch';
    basePath = basePath + basefolder + 'db/';
    var param = 'nid='+nid+'&location=library';
    classleConnect.post(api, param).success(function(response) {
        
      if(response.status == 'Success') {
        var data = response.data;
        var author = data.name;
        var filename = data.downloadName;
        var query = "INSERT INTO contents VALUES("+data.nid+", '"+data.type+"', '"+JSON.stringify(data)+"', '"+author+"', 'classledb')";
        var sParam = {'name':'classledb','path':"default",'query':query};
        classleConnect.loadLocalData(sParam,function(datas) {
            if(data.download) {
                var query1 = "INSERT INTO download VALUES("+data.nid+", '"+filename+"', '"+data.downloadUrl+"', '', 'classle.net', 0)";
                var dParam = {'name':'classledb','path':"default",'query':query1};
                classleConnect.loadLocalData(dParam, function(data) {
                    $rootScope.toast('Sync completed. Please be patient while the content downloads.');
                }, function(datas) {
                    $rootScope.toast("Sync error, Please try again.");
                });
            }else {
              $rootScope.toast('Sync completed.');  
            }
            
        }, function(data) {
           $rootScope.toast('Something went wrong! Please try again later!');
        });
      }else
        $rootScope.toast('Something went wrong! Please try again later!');
    }).error(function(response) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });   
  }
}]);

module.controller('libraryOfflineCtrl',['$scope', 'classleConnect', '$rootScope',function($scope, classleConnect, $rootScope) {
     if($rootScope.networkStatus)
         return;
    $scope.doOfflineSearch = function(sText) {
        if(sText != 'all')
            var query = "SELECT data FROM contents WHERE data LIKE '%"+sText+"%'";
        else
            var query = "SELECT data FROM contents";
        
        var p = {'name':'classledb','path':'default','query':query,'tableName':'contents'};
        classleConnect.getlocaldata(p,function(data) {
            if(data.row != null) {
                $scope.avail = true;
                $scope.data = data.row;
                for(var i = 0;i < $scope.data.length; i++) {
                   $scope.data[i].data = JSON.parse($scope.data[i].data);
                }
            }else
                $scope.avail = false;
        }, function(data) {
            $rootScope.toast('Something went wrong! Please try again later!');
        });
    }
    $scope.doOfflineSearch('all');
}]);

module.controller('libraryContentViewOnline', ['$scope', '$rootScope', 'classleConnect', '$sce', '$routeParams', 'flowPlayerService','$cordovaFileTransfer', '$cordovaFile', '$cordovaDialogs', function($scope, $rootScope, classleConnect, $sce, $routeParams, flowPlayerService,$cordovaFileTransfer, $cordovaFile, $cordovaDialogs) {

    $scope.nid = $routeParams.nid;
    var api = 'newclassle/content/info';
    var param = 'limit=4&node='+$scope.nid+'&offset=0';
    classleConnect.post(api, param).success(function(response) {
        $scope.content = response;
        $scope.body_content = $sce.trustAsHtml(response.body);
    
        switch(response.type) {
            case 'videolink':
                flowPlayerService.construct(response.field_video_url[0].embed);
                $scope.videoLink = response.field_video_url[0].embed;
                break;
            case 'video_content':
                $scope.videoLink = response.field_video_attachment[0].filepath;
                flowPlayerService.construct(response.field_video_attachment[0].filepath);
                
                break;
            case 'audio_content':
                $scope.videoLink = response.field_audio_attachment[0].filepath;
                flowPlayerService.construct(response.field_audio_attachment[0].filepath);
                break;
            case 'course_trailer':
                $scope.videoLink = response.field_course_trailer_link[0].embed;
                flowPlayerService.construct(response.field_course_trailer_link[0].embed);
                break;
            default:
                return;
        }
    }).error(function(response) {
       $rootScope.toast('Something went wrong! Please try again later!');
    });
    
    $scope.dispContent = function(nodeContent, nodeTitle) {
        
        $cordovaDialogs.spinnetStart('Downloading','Please wait...');
        document.addEventListener('deviceready', function() {
           var filetransfer = new FileTransfer();
            filetransfer.onprogress = function(progressEvent) {
                if(progressEvent.lengthComputable) {
                    var perc = Math.floor(progressEvent.loaded / progressEvent.total * 100);
                    
                }
            };
            var fileDownloadPAth = cordova.file.externalRootDirectory + 'download/'+nodeTitle;
            $cordovaFileTransfer.download(nodeContent, fileDownloadPAth, {}, true).then(function(success) {
                $cordovaDialogs.spinnerStop();
                                
               classleConnect.webIntent(success.nativeURL, $scope.content.downloadmime, function(){}, function(){});
            }, function(error) {
                $rootScope.toast('Something went wrong! Please try again later!');
            });
        });
    }
}]);

/*
*  Library post Reply comment controller
*/
module.controller('postReplyCtrl', ['$scope','classleConnect', '$routeParams', '$rootScope', function($scope, classleConnect, $routeParams, $rootScope){
	var nid = $routeParams.nid;
	$scope.pageid = nid;
	var instance = 'classle';
	$scope.replyComment = function(cid, comment) {
		var param = "node=" + nid + "&comment=" + comment +"&pid="+ cid;
        var api ='newclassle/content/postcmt';
		if(comment) {
			classleConnect.post(api,param).success(function(data) {		
			  $scope.cid = data;
		      $rootScope.toast('Successfully Posted!');
			}).error(function(data){
                $rootScope.toast('Something went wrong! Please try again later!');
            });
		}
	}     
}]);

/*
 *  Library post comment controller
 */
module.controller('postCommentCtrl', ['$scope', 'classleConnect', '$routeParams','$rootScope','$route', function($scope, classleConnect, $routeParams, $rootScope, $route) {
  $scope.spinner = true;
  var nid = $routeParams.nid;
  $scope.pageid = nid;
  $scope.postComment = function() {
    if($scope.comment == undefined) {
        $rootScope.toast('Something went wrong! Please try again later!');
        return;
    }
    var param = "node=" + nid + "&comment=" + $scope.comment;
    var api ='newclassle/content/postcmt';
    classleConnect.post(api, param).success(function(data) {
      $scope.cid = data;
      window.location.reload();
      $rootScope.toast( 'Successfully Posted!');
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
  }
}]);

/*
*  Library send message controller
*/
module.controller('sendMsgCtrl', ['$scope', 'classleConnect', '$routeParams', '$rootScope', function($scope, classleConnect, $routeParams,$rootScope){
	$scope.spinner = true;
	var nid = $routeParams.nid;

	$scope.sendmsg = function(name, subject, message) {
		var param = "name=" + name + "&subject=" + subject + "&msg=" + message;
		classleConnect.post(param).success(function(data) {
			if(data == 'send')		
				$rootScope.toast('Successfully sent!');
			else
				$rootScope.toast('Something went wrong! Please try again later!');
			$('#sendmsgModal').modal('hide');
		}).error(function(data){
            $rootScope.toast('Something went wrong! Please try again later!');
        });
	}   
}]);

/*
 *  Library related content controller
 */
module.controller('relatedContentOnlineCtrl', ['$scope', '$rootScope', 'classleConnect', '$routeParams', function($scope, $rootScope, classleConnect, $routeParams) {
  $scope.spinner = true;
  var nid = $routeParams.nid;
  var param = 'nid=' + nid;
  var api = 'newclassle/content/relatedcontent';
  classleConnect.post(api,param).success(function(data) {
    $scope.items = data;
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });
}])
/**
 * library content view offline
 */

module.controller('libraryContentViewOffline', ['$scope', '$rootScope', 'classleConnect', '$routeParams','$sce', function($scope, $rootScope, classleConnect, $routeParams, $sce) {
    var nid = $routeParams.nid;
    var q = 'select c.data, d.filename as fname,d.devicepath,d.status FROM contents c JOIN download d on c.nid = d.nid ';
    var name = 'contents';
    var dbName = 'classledb';
    var param = {"name":dbName, "path":'default', "tableName":name, "query":q};
    classleConnect.getlocaldata(param, function(data) {
        if(data.row != null) {
            $scope.dataContent = JSON.parse(data.row[0].data);
            $scope.downloadStatus = data.row[0].status;
            if(data.row[0].status == 1) {
                $scope.fileName = data.row[0].fname;
                $scope.filepath = data.row[0].devicepath;
            }else {
                $scope.fileName = "File not yet downloaded.";
            }
            $scope.body = $sce.trustAsHtml($scope.dataContent.body);
        }
    }, function(errorData) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
    
    $scope.dispContent = function(filepath, mime) {
        classleConnect.webIntent(filepath, mime, function(){},
            function(){
                $rootScope.toast("Unable to find an appropriate application to open the file.");
            }
        );   
    }
}]);

/**
 * Given by Karthick starts here
 */

/*
 * LC Membership controller
*/ 
module.controller('lcHomeCtrl', ['$scope', '$routeParams', 'lcTitle', 'lcHome', '$rootScope',function($scope, $routeParams, lcTitle, lcHome, $rootScope) {
    $scope.nid = $routeParams.nid;
    var param = 'nid='+$routeParams.nid;
    var user = $rootScope.user;
    $scope.items;
    lcTitle.getLcTitle(param).success(function(data) {
        $scope.title = data.title;
    }).error(function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });

    var param = 'uid=182197&nid='+$routeParams.nid;
    lcHome.getLcHome(param).success(function(data) {
        $scope.items = data;
    }).error(function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
    });
}]);
/*
 * LC Bookmark controller
 */
module.controller('lcBookmarkCtrl', ['$scope', 'lcTitle', 'learningCircleBook', 'learningCircleBookSearch', 'learningCircleBookcontent', '$routeParams', '$sce','$rootScope', function($scope, lcTitle, learningCircleBook, learningCircleBookSearch, learningCircleBookcontent, $routeParams, $sce, $rootScope) {
	$scope.nid = $routeParams.nid;
  var param = 'nid='+$scope.nid;

  lcTitle.getLcTitle(param).success(function(data) {
    $scope.title = data.title;
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });
  var data = 'nid='+$scope.nid+'&from=0&count=5';
  learningCircleBook.getLcBook(data).success(function(data) {
    $scope.items = data;
		//$scope.flag = $sce.trustAsHtml(data.link["flag"]);
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });

  // textbox search for bookmarked contents
  $scope.searchBookmark = function() {
      var param = "nid="+$scope.nid+"&from=0&count=5&key=" + this.keywords;
				$scope.key = this.keywords;
      learningCircleBookSearch.getLcBookSearch(param).success(function(data) {
        $scope.items = data;
				//$scope.flag = $sce.trustAsHtml(data.link["flag"]);
      }).error(function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
      });
    }

  // content type search for bookmarked contents
  $scope.loadBookmark = function(item) {
    if (item) {
      var param = "nid="+$scope.nid+"&from=0&count=5&key=" + item;
			$scope.choice = item;
      learningCircleBookcontent.getLcBookContent(param).success(function(data) {
        $scope.items = data;
				//$scope.flag = $sce.trustAsHtml(data.link["flag"]);
      }).error(function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
      });
    }
  }

	$scope.changePage = function(page) {
		var keyword = angular.isUndefined($scope.key);
		var choices = angular.isUndefined($scope.choice);
		if(!keyword) {
			var param = "nid="+$scope.nid+"&from="+(page - 1)+"&count=5&key=" + $scope.key;
      learningCircleBookSearch.getLcBookSearch(param).success(function(data) {
        $scope.items = data;
				$scope.flag = $sce.trustAsHtml(data.link['flag']);
      }).error(function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
      });
		}
		if(!choices) {
			var param = "nid="+$scope.nid+"&from="+(page - 1)+"&count=5&key=" + $scope.choice;
      learningCircleBookcontent.getLcBookContent(param).success(function(data) {
        $scope.items = data;
				$scope.flag = $sce.trustAsHtml(data.link['flag']);
      }).error(function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
      });
		}
		if(keyword && choices) {
			var data = 'nid='+$scope.nid+'&from='+(page - 1)+'&count=5';
			learningCircleBook.getLcBook(data).success(function(data) {
				$scope.items = data;
				$scope.flag = $sce.trustAsHtml(data.link['flag']);
			}).error(function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
			});
		}
	}
}]);

 /*LC Assignment*/
module.controller('lcAssignmentCtrl', ['$scope', '$rootScope', '$routeParams', 'lcTitle', 'lcassignment', 'lcassignmentsearch', 'lcassignmentsort', function($scope, $rootScope, $routeParams, lcTitle, lcassignment, lcassignmentsearch, lcassignmentsort) {
	$scope.nid = $routeParams.nid;
	var param = 'nid='+$scope.nid;

  lcTitle.getLcTitle(param).success(function(data) {
    $scope.title = data.title;
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });
	var data = 'nid='+$scope.nid+'&from=0&count=5';
	lcassignment.getassignment(data).success(function(data) {
		$scope.items = data;
	}).error(function(data) {
		$rootScope.toast('Something went wrong! Please try again later!');
	});

  // textbox search for Assignment contents
  $scope.searchAssignment = function() {
    $scope.spinner = true;
    var param = "nid="+$scope.nid+"&from=0&count=5&key=" + this.keywords;
		$scope.key = this.keywords;
    lcassignmentsearch.getLcAssignSearch(param).success(function(data) {
      $scope.items = data;
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
  }

  // Sorting for Assignment contents
  $scope.loadAssign = function(item) {
    if (item) {
      $scope.spinner = true;
      var param = "nid="+$scope.nid+"&from=0&count=5&key=" + item;
			$scope.choice = item;
      lcassignmentsort.getLcAssignSort(param).success(function(data) {
        $scope.items = data;
      }).error(function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
      });
    }
  }

	$scope.changePage = function(page) {
		var keyword = angular.isUndefined($scope.key);
		var choices = angular.isUndefined($scope.choice);
		if(!keyword) {
			var param = "nid="+$scope.nid+"&from="+(page - 1)+"&count=5&key=" + $scope.key;
			lcassignmentsearch.getLcAssignSearch(param).success(function(data) {
      $scope.items = data;
		  }).error(function(data) {
		    $rootScope.toast('Something went wrong! Please try again later!');
		  });
		}
		if(!choices) {
			var param = "nid="+$scope.nid+"&from="+(page - 1)+"&count=5&key=" + $scope.choice;
			lcassignmentsort.getLcAssignSort(param).success(function(data) {
        $scope.items = data;
      }).error(function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
      });
		}
		if(keyword && choices) {
			var data = 'nid='+$scope.nid+'&from='+(page - 1)+'&count=5';
			lcassignment.getassignment(data).success(function(data) {
				$scope.items = data;
			}).error(function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
			});
		}
	}
}]);

 /*LC forum*/
module.controller('lcForumCtrl', ['$scope', '$routeParams', 'lcTitle', 'lcForum', 'lcForumSearch', 'lcForumSort','$rootScope', function($scope, $routeParams, lcTitle, lcForum, lcForumSearch, lcForumSort, $rootScope) {
	$scope.nid = $routeParams.nid;
	var param = 'nid='+$scope.nid;

  lcTitle.getLcTitle(param).success(function(data) {
    $scope.title = data.title;
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });

	var data = 'nid='+$scope.nid+'&from=0&count=2';
  lcForum.getLcForum(data).success(function(data) {
    $scope.items = data;
    $scope.spinner = false;
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });

  // textbox search for forum contents
  $scope.searchForum = function() {
    $scope.spinner = true;
    var param = "nid="+$scope.nid+"&from=0&count=2&key=" + this.keywords;
		$scope.key = this.keywords;
    lcForumSearch.getLcForumSearch(param).success(function(data) {
      $scope.items = data;
      $scope.spinner = false;
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
  }

  // Sorting for forum contents
  $scope.loadForum = function(item) {
    if (item) {
      $scope.spinner = true;
      var param = "nid="+$scope.nid+"&from=0&count=2&key=" + item;
			$scope.choice = item;
      lcForumSort.getLcForumSort(param).success(function(data) {
        $scope.items = data;
        $scope.spinner = false;
      }).error(function(data) {
        $rootScope.toast('Something went wrong! Please try again later!');
      });
    }
  }

	$scope.changePage = function(page) {
		var keyword = angular.isUndefined($scope.key);
		var choices = angular.isUndefined($scope.choice);
		if(!keyword) {
			var param = "nid="+$scope.nid+"&from="+(page - 1)+"&count=2&key=" + $scope.key;
		  lcForumSearch.getLcForumSearch(param).success(function(data) {
		    $scope.items = data;
		    $scope.spinner = false;
		  }).error(function(data) {
		    $rootScope.toast('Something went wrong! Please try again later!');
		  });
		}
		if(!choices) {
			var param = "nid="+$scope.nid+"&from="+(page - 1)+"&count=2&key=" + $scope.choice;
              lcForumSort.getLcForumSort(param).success(function(data) {
                $scope.items = data;
                $scope.spinner = false;
              }).error(function(data) {
                $rootScope.toast('Something went wrong! Please try again later!');
              });
		}
		if(keyword && choices) {
			var data = 'nid='+$scope.nid+'&from='+(page - 1)+'&count=2';
			lcForum.getLcForum(data).success(function(data) {
				$scope.items = data;
				$scope.spinner = false;
			}).error(function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
			});
		}
	}
}]);

/*
 * LC Membership controller
 */
module.controller('lcMemberCtrl', ['$scope', '$routeParams', 'lcTitle', 'lcMember', 'lcSuggest', 'leavelc', 'requestownerlc', '$rootScope', function($scope, $routeParams, lcTitle, lcMember, lcSuggest, leavelc, requestownerlc, $rootScope) {
	$scope.nid = $routeParams.nid;
	$scope.uid = $rootScope.user.uid;
	var param = 'nid='+$scope.nid;
  $scope.items;
  $scope.leave;
	$scope.owner = $scope.nid;;
  lcTitle.getLcTitle(param).success(function(data) {
    $scope.title = data.title;
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });

  lcMember.getLcMember(param).success(function(data) {
    $scope.items = data;
    $scope.spinner = false;
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });

  $scope.suggestOwner = function(invitemail, pmessage) {
    var param = 'nid='+$scope.nid+'&mail=' + invitemail + '&message=' + pmessage;
    lcSuggest.getsuggestMember(param).success(function(data) {
      if (data == 'success')
        $rootScope.toast("Successfully invited");
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
  }

	$scope.leaveThisCircle = function() {
    var param = 'node='+$scope.nid;
    leavelc.leaveRequest(param).success(function(data) {
      $rootScope.toast(data);
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
	}

	$scope.requestOwner = function() {
    var param = 'node='+$scope.nid;
    requestownerlc.requestOwner(param).success(function(data) {
      $rootScope.toast(data);
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
	}
}]);
module.controller('myLcofflineCtrl', ['$scope', '$rootScope', 'classleConnect', function($scope, $rootScope, classleConnect) {
    var count = 10;
 	var name = 'classledb'; 
	var path = 'default';
	var tableName = 'lc_table';
	var query = 'SELECT * FROM lc_table GROUP BY gid LIMIT 0, '+count+'';
	var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
	classleConnect.getlocaldata(dbarray,function(data) {
		$scope.items = data.row;
	},function(data) {
		$rootScope.toast('Something went wrong! Please try again later!');
	});	

	var query = 'SELECT COUNT(DISTINCT(gid)) AS total FROM lc_table';
	var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
	classleConnect.getlocaldata(dbarray,function(data) {
		$scope.total = data.row[0].total;
	},function(data) {
		$rootScope.toast('Something went wrong! Please try again later!');
	});	

	$scope.searchLC = function(keyword) {
		$scope.key = keyword;
		var query = 'SELECT * FROM lc_table WHERE name LIKE "%%'+keyword+'%%" GROUP BY gid LIMIT 0, 2';
		var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		classleConnect.getlocaldata(dbarray,function(data) {
			$scope.items = data.row;
		},function(data) {
			$rootScope.toast('Something went wrong! Please try again later!');
		});		
	
		var query = 'SELECT COUNT(DISTINCT(gid)) AS total FROM lc_table WHERE name LIKE "%%'+keyword+'%%"';
		var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		classleConnect.getlocaldata(dbarray,function(data) {
			$scope.total = data.row[0].total;
		},function(data) {
			$rootScope.toast('Something went wrong! Please try again later!');
		});	
	}

	$scope.changePage = function(page) {
		var count = 2;
		var from = (page - 1) * count;
		var keyword = angular.isUndefined($scope.key);
		
		if(!keyword) {
			var query = 'SELECT * FROM lc_table WHERE name LIKE "%%'+keyword+'%%" GROUP BY gid LIMIT '+from+', '+count+'';
			var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
			classleConnect.getlocaldata(dbarray,function(data) {
				$scope.items = data.row;
			},function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
			});	
		}
		else {
			var query = 'SELECT * FROM lc_table GROUP BY gid LIMIT '+from+', 2';
			var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
			classleConnect.getlocaldata(dbarray,function(data) {
				$scope.items = data.row;
			},function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
			});
		}
	}
}]);

module.controller('lcInnerOfflineCtrl', ['$scope', '$rootScope', 'classleConnect', '$routeParams', function($scope, $rootScope, classleConnect, $routeParams) {
    $scope.nid = $routeParams.nid;
	var count = 2;
 	var name = 'classledb'; 
	var path = 'default';
	var tableName = 'lc_table';
	var query = 'SELECT lc.gid, lc.name as circle, lr.nid,lr.rsrc_type,lr.name AS resourse, lr.rname, lr.tags, lr.user_name FROM lc_table lc INNER JOIN lc_rsrc lr ON lc.gid = lr.gid WHERE lc.gid = '+$scope.nid+' GROUP BY lc.gid, lr.nid LIMIT 0, '+count+'';
	var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
	classleConnect.getlocaldata(dbarray,function(data) {
		$scope.items = data.row;
	},function(data) {
		$rootScope.toast('Something went wrong! Please try again later!');
	});	

	var query = 'SELECT COUNT(DISTINCT(lr.nid)) AS total FROM lc_table lc INNER JOIN lc_rsrc lr ON lc.gid = lr.gid WHERE lc.gid = '+$scope.nid;
	var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
	classleConnect.getlocaldata(dbarray,function(data) {
		$scope.total = data.row[0].total;
	},function(data) {
		$rootScope.toast('Something went wrong! Please try again later!');
	});	

	$scope.loadBookmark = function(choice) {
		$scope.choices = choice;
		var query = 'SELECT lc.gid, lc.name as circle, lr.nid,lr.rsrc_type,lr.name AS resourse, lr.rname, lr.tags, lr.user_name FROM lc_table lc INNER JOIN lc_rsrc lr ON lc.gid = lr.gid WHERE lc.gid = '+$scope.nid+' AND lr.rsrc_type LIKE "%%'+choice+'%%" GROUP BY lc.gid, lr.nid LIMIT 0, '+count+'';
		var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		classleConnect.getlocaldata(dbarray,function(data) {
				$scope.items = data.row;
			},function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
		});	

		var query = 'SELECT COUNT(DISTINCT(lr.nid)) AS total FROM lc_table lc INNER JOIN lc_rsrc lr ON lc.gid = lr.gid WHERE lc.gid = '+$scope.nid+' AND lr.rsrc_type LIKE "%%'+choice+'%%"';
		var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		classleConnect.getlocaldata(dbarray,function(data) {
			$scope.total = data.row[0].total;
		},function(data) {
			$rootScope.toast('Something went wrong! Please try again later!');
		});	
	}

	$scope.searchBookmark = function() {
		$scope.key = $scope.keywords;
		var query = 'SELECT lc.gid, lc.name as circle, lr.nid,lr.rsrc_type,lr.name AS resourse, lr.rname, lr.tags, lr.user_name FROM lc_table lc INNER JOIN lc_rsrc lr ON lc.gid = lr.gid WHERE lc.gid = '+$scope.nid+' AND lr.name LIKE "%%'+$scope.keywords+'%%" GROUP BY lc.gid, lr.nid LIMIT 0, '+count+'';
		var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		classleConnect.getlocaldata(dbarray,function(data) {
				$scope.items = data.row;
			},function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
		});	

		var query = 'SELECT COUNT(DISTINCT(lr.nid)) AS total FROM lc_table lc INNER JOIN lc_rsrc lr ON lc.gid = lr.gid WHERE lc.gid = '+$scope.nid+' AND lr.name LIKE "%%'+$scope.keywords+'%%"';
		var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		classleConnect.getlocaldata(dbarray,function(data) {
			$scope.total = data.row[0].total;
		},function(data) {
			$rootScope.toast('Something went wrong! Please try again later!');
		});	
	}

	$scope.changePage = function(page) {
		var count = 2;
		var from = (page - 1) * count;
		var keyword = angular.isUndefined($scope.key);
		var choices = angular.isUndefined($scope.choices);

		if(!keyword) {
			var query = 'SELECT lc.gid, lc.name as circle, lr.nid,lr.rsrc_type,lr.name AS resourse, lr.rname, lr.tags, lr.user_name FROM lc_table lc INNER JOIN lc_rsrc lr ON lc.gid = lr.gid WHERE lc.gid = '+$scope.nid+' AND lr.name LIKE "%%'+$scope.keywords+'%%" GROUP BY lc.gid, lr.nid LIMIT '+from+', '+count+''; 
		}
		if(!choices) {
			var query = 'SELECT lc.gid, lc.name as circle, lr.nid,lr.rsrc_type,lr.name AS resourse, lr.rname, lr.tags, lr.user_name FROM lc_table lc INNER JOIN lc_rsrc lr ON lc.gid = lr.gid WHERE lc.gid = '+$scope.nid+' AND lr.rsrc_type LIKE "%%'+$scope.choices+'%%" GROUP BY lc.gid, lr.nid LIMIT '+from+', '+count+'';
		}
		if(keyword && choices) {
			var query = 'SELECT lc.gid, lc.name as circle, lr.nid,lr.rsrc_type,lr.name AS resourse, lr.rname, lr.tags, lr.user_name FROM lc_table lc INNER JOIN lc_rsrc lr ON lc.gid = lr.gid WHERE lc.gid = '+$scope.nid+' GROUP BY lc.gid, lr.nid LIMIT '+from+', '+count+'';
		}

		var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		classleConnect.getlocaldata(dbarray,function(data) {
			$scope.items = data.row;
		},function(data) {
			$rootScope.toast('Something went wrong! Please try again later!');
		});	
	}
}]);
/**
 * Inner Course Starts here
 */

/*
 * course home controller
*/ 
module.controller('courseInfoCtrl', ['$scope', 'courseAboutFactory', '$sce', '$rootScope', '$route','$routeParams', function($scope, courseAboutFactory, $sce, $rootScope, $route,$routeParams) {
  var nid = $routeParams.nid;
  $scope.courseInfo = '';
  $rootScope.courseId = nid;
  courseAboutFactory.getInfo(nid).success(function(data) {
    $scope.courseInfo = data;
    $rootScope.menu = data.signup;
	$rootScope.coursename = data.title;
    $scope.course_description = $sce.trustAsHtml(data.description);
    $scope.course_syllabus = $sce.trustAsHtml(data.syllabus);
    $scope.course_prerequisites = $sce.trustAsHtml(data.prerequisites);
    $scope.course_suggested = $sce.trustAsHtml(data.suggested);
    $scope.course_format = $sce.trustAsHtml(data.course_format);
    $scope.course_faq = $sce.trustAsHtml(data.faq);
    var author = data.authors;
    for (var i = 0; i < author.length; i++) {
      author[i].description = $sce.trustAsHtml(author[i].description);
    }
    $scope.faculty = author;
    //$scope.uid = $rootScope.user.uid;
    if (data.msg)
      $rootScope.toast(data.msg);
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });

  $scope.paymethod = function(method) {
    courseAboutFactory.addCart(nid, method).success(function(data) {
      if (data.link) {
        window.location = data.link;
			}
      else {
        window.location.reload();
			}
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
  }
}]);

/*
 * course announcement controller
*/ 

module.controller('courseAnnouncementCtrl', ['$scope', 'courseAnnouncements', '$sce','$routeParams', '$rootScope', function($scope, courseAnnouncements, $sce, $routeParams, $rootScope) {
  var nid = $routeParams.nid;
    $rootScope.courseId = nid;
  courseAnnouncements.getAnnouncements(nid).success(function(data) {
    for (var i = 0; i < data.length; i++) {
      data[i].description = $sce.trustAsHtml(data[i].description);
    }
    $scope.courseInfo = data;
    if (data.completion) {
      $rootScope.toast('Course Completed ! No view available for announcements.');
    }
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });
}]);

/*
 * course modules controller
*/ 

module.controller('courseModulesCtrl', ['$scope', 'courseModules', '$routeParams', '$rootScope' , 'mycoursessync','classleConnect', '$route', function($scope, courseModules, $routeParams, $rootScope, mycoursessync, classleConnect, $route) {
  var nid = $routeParams.nid;
  $rootScope.courseId = nid;
  $scope.spinner = true;
  courseModules.getCourseModules(nid).success(function(data) {
    $scope.courseInfo = data;
    $scope.spinner = false;
  }).error(function(data) {
   $rootScope.toast('Something went wrong! Please try again later!');
  });
    
    //Sync content
    
  $scope.quizsync = function(contentnid){ 
    var datadir = cordova.file.externalRootDirectory;
    datadir = datadir.replace('file://', '');  
    var filePath = datadir + "com.classle.classlemobile/files";
    mycoursessync.mycoursessyncDetails(contentnid, filePath).success(function(data) {
        var name = 'classledb'; 
        var path = 'default';
        if(data.type == 'flip'){
            if(data.cuequiz != undefined)
                var cuequiznid =data.cuequiz;
            else
                var cuequiznid = 0;
            var rname = data.rname;
        }else{
            var cuequiznid = data.nid;
            var rname = '';
        }
        query = "insert into course_resource (gid,nid,quiz_id,name,type,rname,language,parent) values("+data.courseid+","+data.nid+","+cuequiznid+",'"+data.title+"','"+data.type+"','"+rname+"','english',"+data.moduleid+")";
        var dbarray = {'name': name, 'path': path, 'query': query};
        classleConnect.loadLocalData(dbarray, function(data){
        },
        function (data){
            $rootScope.toast('Something went wrong. Please try again later');
        });

        query = "insert into course_module (gid,nid,title) values("+data.courseid+","+data.moduleid+",'"+data.module_name+"')";
        var dbarray = {'name': name, 'path': path, 'query': query};
        classleConnect.loadLocalData(dbarray, function(data){
        },
        function (data){
            $rootScope.toast('Something went wrong. Please try again later');
        });

        if(data.type == 'quiz'){
        //first table
            query = "insert into quiz(quiz_id,name,language) values("+data.nid+",'"+data.title+"','english')";
            var dbarray = {'name': name, 'path': path, 'query': query};
            classleConnect.loadLocalData(dbarray, function(data){
            },
            function (data){
                $rootScope.toast('Something went wrong. Please try again later');
            });
            //first end

            for(var i=0;i<data.len;i++){
                query = "insert into questions(qid,quiz_id ,question,qtype,options,correct_opt,attempts,current_choice,langugage,cuepoint) values("+data.allquestions[i].qnid+","+data.nid+",'"+data.allquestions[i].title+"','"+data.allquestions[i].qtype+"','"+data.allquestions[i].dbchoices+"','"+data.allquestions[i].correct_opt+"',0,1000,'english','')";
                var dbarray = {'name': name, 'path': path, 'query': query};
                classleConnect.loadLocalData(dbarray, function(data){
                },
                function (data){
                  $rootScope.toast('Something went wrong. Please try again later');
                });

            //for img quiz dowload table
            if(data.allquestions[i].imgpath){
                query = "insert into download(nid,filename,filepath,status) values("+data.allquestions[i].qnid+",'"+data.allquestions[i].imgname+"','"+data.allquestions[i].imgpath+"',0)";
                var dbarray = {'name': name, 'path': path, 'query': query};
                classleConnect.loadLocalData(dbarray, function(data){
                },
                function (data){
                    $rootScope.toast('Something went wrong. Please try again later');
                });
            }
                //img end
                //for img choices quiz dowload table
                var quest = data.allquestions[i];
                if(quest.choices){
                var choiclen = quest.choices;
                if(choiclen.length){
                    for(var k=0; k<choiclen.length;k++){
                        if(choiclen[k].imgname){
                            query = "insert into download(nid,filename,filepath,status) values("+choiclen[k].id+",'"+choiclen[k].imgname+"','"+choiclen[k].imgpath+"',0)";
                            var dbarray = {'name': name, 'path': path, 'query': query};
                            classleConnect.loadLocalData(dbarray, function(data){
                            },
                            function (data){
                                $rootScope.toast('Something went wrong. Please try again later');
                            });							
                        }
                    }
                 }
             }
            //end img choices quiz dowload table

            }
        }
        else if(data.type == 'flip'){
            if(data.cuequiz){
                query = "insert into quiz(quiz_id,name,language) values("+data.cuequiz+",'"+data.cuequiztitle+"','english')";
                var dbarray = {'name': name, 'path': path, 'query': query};
                classleConnect.loadLocalData(dbarray, function(data){
                    
                },
                function (data){
                    $rootScope.toast('Something went wrong. Please try again later');
                });

                    //for flip video 
                    query = "insert into download(nid,filename,filepath,status) values("+data.nid+",'"+data.flipname+"','"+data.videolink+"',0)";
                    var dbarray = {'name': name, 'path': path, 'query': query};
                    classleConnect.loadLocalData(dbarray, function(data){
                    },
                    function (data){
                        $rootScope.toast('Something went wrong. Please try again later');
                    });

                    // flip video end

                for(var i=0;i<data.len;i++){
                    query = "insert into questions(qid,quiz_id ,question,qtype,options,correct_opt,attempts,current_choice,langugage,cuepoint) values("+data.allquestions[i].qnid+",'"+data.cuequiz+"','"+data.allquestions[i].title+"','"+data.allquestions[i].qtype+"','"+data.allquestions[i].dbchoices+"','"+data.allquestions[i].correct_opt+"',0,1000,'english',"+data.allquestions[i].eachcuetimes+")";
                    var dbarray = {'name': name, 'path': path, 'query': query};
                    classleConnect.loadLocalData(dbarray, function(data){
                        
                    },
                    function (data){
                        $rootScope.toast('Something went wrong. Please try again later');
                    });

                //for img quiz dowload table
                if(data.allquestions[i].imgpath){
                    query = "insert into download(nid,filename,filepath,status) values("+data.allquestions[i].qnid+",'"+data.allquestions[i].imgname+"','"+data.allquestions[i].imgpath+"',0)";
                    var dbarray = {'name': name, 'path': path, 'query': query};
                    classleConnect.loadLocalData(dbarray, function(data){
                        
                    },
                    function (data){
                        $rootScope.toast('Something went wrong. Please try again later');
                    });
                }
                //img end


                                                            //for img choices quiz dowload table
                var quest = data.allquestions[i];
                if(quest.choices){
                var choiclen = quest.choices;
                if(choiclen.length){
                    for(var k=0; k<choiclen.length;k++){
                        if(choiclen[k].imgname){
                            query = "insert into download(nid,filename,filepath,status) values("+choiclen[k].id+",'"+choiclen[k].imgname+"','"+choiclen[k].imgpath+"',0)";
                            var dbarray = {'name': name, 'path': path, 'query': query};
                            classleConnect.loadLocalData(dbarray, function(data){
                                
                            },
                            function (data){
                                $rootScope.toast('Something went wrong. Please try again later');
                            });							
                        }
                    }
                 }
             }
            //end img choices quiz dowload table
        }
         }else {
               //for flip video 
                query = "insert into download(nid,filename,filepath, status) values("+data.nid+",'"+data.flipname+"','"+data.videolink+"',0)";
                var dbarray = {'name': name, 'path': path, 'query': query};
                classleConnect.loadLocalData(dbarray, function(data){
                },
                function (data){
                    $rootScope.toast('Something went wrong. Please try again later');
                });   
         }
        }
        query = "UPDATE courses SET sync_status = 1 WHERE gid = " + data.courseid;
        var dbarray = {'name': name, 'path': path, 'query': query};
        classleConnect.loadLocalData(dbarray, function(data){
            $rootScope.toast("Sync Successfully completed.");
            $route.reload();
        },
        function (data){
            $rootScope.toast("Something went wrong! Please try again later");
        });
    }).error(function(data) {
      $rootScope.toast('Something went wrong. Please try again later');
    });
}
}]);
/*
 * course assignment controller
*/ 
module.controller('courseAssignmentCtrl', ['$scope','courseAssignment', '$routeParams', '$rootScope', function($scope, courseAssignment,$routeParams, $rootScope) {
  var nid = $routeParams.nid;
    $rootScope.courseId = nid;
  courseAssignment.getCourseAssignment(nid).success(function(data) {
    $scope.courseInfo = data;
    if (data.completion) {
      $rootScope.toast('Course Completed ! No view available for assignments.');
    }
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });
    
    $scope.Openassign = function(nid) {
        window.plugins.webintent.startActivity(
            {
                action: window.plugins.webintent.ACTION_VIEW,
                url: 'http://test.classle.in/newgan/#/course+/content/'+nid +'/',
            },
            function() {},
            function() {$rootScope.toast('Failed to open URL browser.');}
        );
    }
}]);
/*
 * course circle controller
*/ 
module.controller('courseCircleCtrl', ['$scope', 'courseCircles','$routeParams', '$rootScope', function($scope, courseCircles, $routeParams, $rootScope) {
  var nid = $routeParams.nid;
    $rootScope.courseId = nid;
  $scope.courseid = $routeParams.nid;
  var searchstring = '';
  var sortsvalue = '';
  $scope.spinner = true;
  courseCircles.getCourseCircles(nid, sortsvalue, searchstring).success(function(data) {
    $scope.courseInfo = data;
    $scope.spinner = false;
    if (data.completion) {
      $rootScope.toast('Course Completed ! No view available for circles.');
    }
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });

  // Sorting for Assignment contents
  $scope.circlesort = function(sortsvalue) {
    var nid = $routeParams.nid;
      $rootScope.courseId = nid;
    var searchstring = '';
    courseCircles.getCourseCircles(nid, sortsvalue, searchstring).success(function(data) {

      $scope.courseInfo = data;
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
  }

  $scope.searchsubmit = function(searchstring) {
    var nid = $routeParams.nid;
      $rootScope.courseId = nid;
    var sortsvalue = '';
    courseCircles.getCourseCircles(nid, sortsvalue, searchstring).success(function(data) {
      $scope.courseInfo = data;
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
  }
}]);

/*
 * course ask controller
*/ 
module.controller('courseAskCtrl', ['$scope', 'courseAsk','$routeParams', '$rootScope' ,function($scope, courseAsk, $routeParams, $rootScope) {
  var nid = $routeParams.nid;
    $rootScope.courseId = nid;
  $scope.courseid = $routeParams.nid;
  var searchstring = '';
  var asks = '';
  $scope.spinner = true;
  courseAsk.getCourseAsk(nid, asks, searchstring).success(function(data) {
    $scope.courseInfo = data;
    $scope.spinner = false;
    if (data.completion) {
      $rootScope.toast('Course Completed ! No view available for ask.');
    }
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });

  // Sorting for Assignment contents
  $scope.asksort = function(asks) {
    var nid = $routeParams.nid;
      $rootScope.courseId = nid;
    var searchstring = '';
    courseAsk.getCourseAsk(nid, asks, searchstring).success(function(data) {
      $scope.courseInfo = data;
    }).error(function(data) {
       $rootScope.toast('Something went wrong! Please try again later!');
    });
  }

  $scope.searchsubmit = function(searchstring) {
    var nid = $routeParams.nid;
      $rootScope.courseId = nid;
    var asks = '';
    courseAsk.getCourseAsk(nid, asks, searchstring).success(function(data) {
      $scope.courseInfo = data;
    }).error(function(data) {
       $rootScope.toast('Something went wrong! Please try again later!');
    });
  }
}]);

/*
 * course resource controller
*/ 
module.controller('courseResourceCtrl', ['$scope', 'courseResources', '$routeParams','$rootScope',function($scope, courseResources ,$routeParams, $rootScope) {
  var nid = $routeParams.nid;
    $rootScope.courseId = nid;
  var searchstring = '';
  var pagetypes = '';
  $scope.spinner = true;
  courseResources.getCourseResources(nid, pagetypes, searchstring).success(function(data) {
    $scope.courseInfo = data;
    $scope.spinner = false;
    if (data.completion) {
      $rootScope.toast('Course Completed ! No view available for resources.');
    }
  }).error(function(data) {
    $rootScope.toast('Something went wrong! Please try again later!');
  });

  $scope.pagetype = function(pagetypes) {
    var nid = $routeParams.nid;
      $rootScope.courseId = nid;
    var searchstring = '';
    courseResources.getCourseResources(nid, pagetypes, searchstring).success(function(data) {
      $scope.courseInfo = data;
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
  }

  $scope.searchsubmit = function(searchstring) {
    var nid = $routeParams.nid;
      $rootScope.courseId = nid;
    var pagetypes = '';
    courseResources.getCourseResources(nid, pagetypes, searchstring).success(function(data) {
      $scope.courseInfo = data;
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
  }
}]);

/*
* quiz controller
*/

module.controller('quizQuestionsCtrl', ['$scope', 'quizQuestionsFactory', 'quizAnswersFactory', '$sce', '$routeParams', '$rootScope', function($scope,quizQuestionsFactory,quizAnswersFactory,$sce, $routeParams, $rootScope) {
 	$scope.showresults = false;
	var d = "quizid="+$routeParams.qnid;
	quizQuestionsFactory.quizAllQuestions(d).success(function(data) {
		$scope.coursetitle = data.coursetitle;
		$scope.quiztitle = data.quiztitle;
		$scope.countdowns = [{countdownval:data.quizseconds}]; 
		$scope.timedquizcheck = data.quizseconds;
		data = data.allquestions;
		$scope.questionlength = data.length;
		for(var i=0; i< data.length; i++) {
			data[i].title = $sce.trustAsHtml(data[i].title);
			var ans = data[i].answers;
			for  (var choicesid in ans) {
				ans[choicesid] = $sce.trustAsHtml(ans[choicesid]);
			}
			data[i].answers = ans;
		}
		$scope.quizzess = data;
	}).error(function(data){
        $rootScope.toast('Something went wrong! Please try again later!');
    });
	var quizanswerid = {};
	var questionids = {};
	var newquestionids = [];
	$scope.getanswers = {};
	$scope.quizresults = function(getanswers){	
		var cc = $scope.quizzess;
		for(var i=0; i< cc.length; i++){
			var questnid = cc[i].qnid;
			if(cc[i].type == 'cloze'){
			var singlefillup =  document.getElementById("fillups_" + questnid);
			var fillvalue = singlefillup.value;
			if(fillvalue != ''){
				$scope.getanswers[questnid] = fillvalue;
			}
			}
			else {
				var mcq = document.getElementsByName(questnid);
				for (var j=0;j<mcq.length;j++){
					if ( mcq[j].checked ) {
						$scope.getanswers[questnid] = mcq[j].value;
					}
				}
			}
		}
		var answerlength = Object.keys($scope.getanswers).length;
		if($scope.timedquizcheck){
			var answerlength = $scope.questionlength;
		}
        if(answerlength == $scope.questionlength){
            $scope.getanswers['quiznid'] = $routeParams.qnid;
            quizAnswersFactory.quizAllAnswers($scope.getanswers).success(function(data) {
            $scope.rest = {};
            $scope.totalquestions = data.totalquestions;
            $scope.usercorrect = data.usercorrect;
            $scope.showresults = true;
            data = data.alluseranswers;
            for(var i=0; i< data.length; i++) {
                data[i].question = $sce.trustAsHtml(data[i].question);
                var ans = data[i].choices;
                for  (var choicesid in ans) {
                    ans[choicesid] = $sce.trustAsHtml(ans[choicesid]);
                }
                data[i].choices = ans;
                if(data[i].type == 'cloze'){
                    data[i].user_answer = $sce.trustAsHtml(data[i].user_answer);
                }	
            }
            $scope.quizresults = data;
            }).error(function(data){
                $rootScope.toast("Something went wrong! Please try again later");
            });
        }
        else{
            $rootScope.toast("Oops! You haven't completed the quiz. Please make sure you answer all the questions before submitting.");
        }
	}
}]);

/**
 * course inner offline starts here
 */

/*function for displaying modules*/
module.controller('courseModulesOfflineCtrl', ['$scope', 'classleConnect', '$rootScope','$routeParams', function($scope, classleConnect, $rootScope, $routeParams) {
	$rootScope.showresult = false;
	$rootScope.answer = [];
    var cid = $routeParams.nid;
    $rootScope.courseId = cid;
 	var name = 'classledb'; 
	var path = 'default';
	var tableName = 'course_module';
	$scope.items = [];
	var query = 'SELECT DISTINCT(cm.nid) as module, cm.title, cr.nid as quiz_id, cr.name, cr.type, c.name AS coursename FROM course_module cm INNER JOIN course_resource cr on cm.nid = cr.parent INNER JOIN courses c ON cm.gid = c.gid WHERE cm.gid= '+ cid +' group by quiz_id,module';
	var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
	classleConnect.getlocaldata(dbarray,function(data) {
	var xmid = '';
	for(var i = 0; i < data.row.length; i++) {
		var cname = data.row[i].coursename;
		var mname = data.row[i].title;
		var mid = data.row[i].module;
	    var qid = data.row[i].quiz_id;
		var qname = data.row[i].name;
		var qtype = data.row[i].type;
		if(mid != xmid) {
			$scope.quizes = [];
			$scope.quizes.push({'quiztitle': qname, 'quizid' : qid, 'quiztype' : qtype});
			$scope.items.push({'coursename': cname, 'modulename': mname, 'moduleid' : mid, 'quizcontent' : $scope.quizes});
		}
		else {
			var s = i;
			for(var j = 0; j <= s; j++)	{
				s = s-1;
			}
			$scope.innerquizes = {'quiztitle': qname, 'quizid' : qid, 'quiztype' : qtype};
			$scope.items[s].quizcontent.push($scope.innerquizes);
		}
		xmid = mid;
	}
	},function(data) {
		$rootScope.toast('Something went wrong! Please try again later!');
	});

	/*flip function*/
	$scope.flipIntent = function(fid) {
	 	var name = 'classledb'; 
		var path = 'default';
		var tableName = 'download';
		var query = 'SELECT devicepath FROM download WHERE nid='+fid;
		var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		classleConnect.getlocaldata(dbarray,function(data) {
            if(data.row[0].status) {
                var type = 'video/mp4';
                var path = "file://"+data.row[0].devicepath;
                window.plugins.webintent.startActivity({
                   action: window.plugins.webintent.ACTION_VIEW,
                   url: path,
                   type: type},
                   function() {},
                   function(msg) {
                      $rootScope.toast("Unable to find an appropriate application to open the file.");
                   }
                );
            }else {
                $rootScope.toast("File has not been downloaded");   
            }
		},function(data) {
			$rootScope.toast(data);
		});
	}
}]);

/*function for processing quiz*/
module.controller('quizQuestionCtrl', ['$scope', 'classleConnect', '$routeParams', '$sce', '$route', '$rootScope', function($scope, classleConnect, $routeParams, $sce, $route, $rootScope) {
	var moduleid = $routeParams.mid;
	var quizid = $routeParams.qid;
 	var name = 'classledb'; 
	var path = 'default';
	var tableName = 'questions';
	$scope.items = [];
	//var query = 'SELECT q.*, m.title AS modulename,c.name AS coursename FROM questions q INNER JOIN course_module m ON m.qid = q.quiz_id INNER JOIN courses c ON m.gid = c.gid WHERE q.quiz_id ='+ quizid +' AND q.attempts = 0';
    var query = "SELECT qs.*,cm.title AS modulename, c.name AS coursename  FROM course_resource cr INNER JOIN quiz q ON q.quiz_id = cr.quiz_id INNER JOIN questions qs ON qs.quiz_id =  cr.quiz_id INNER JOIN course_module cm ON cm.nid = cr.parent INNER JOIN courses c ON c.gid = cm.gid WHERE qs.attempts = 0 AND cr.quiz_id ="+quizid;
	var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
	classleConnect.getlocaldata(dbarray,function(data) {
		$scope.items = data.row;
		for(var i = 0; i < data.row.length; i++) {
			$scope.items[i].question = $sce.trustAsHtml($scope.items[i].question);
			$scope.items[i].options = JSON.parse($scope.items[i].options);
			for(var e = 0; e < $scope.items[i].options.length; e++) {
				$scope.items[i].options[e] = $sce.trustAsHtml($scope.items[i].options[e]);
			}
		}
		//alert(JSON.stringify($scope.items));
	},function(data) {
		$rootScope.toast('Something went wrong! Please try again later!');
	});

	$scope.submitQuiz = function() {
		/*validation for quiz*/
		var s = 0;
		for(var j = 0; j < $scope.items.length; j++) {
     var inputs = document.getElementsByName($scope.items[j].qid);
	   for (var i = 0; i < inputs.length; i++) {
				if($scope.items[j].qtype == 'cloze')	{
					if(inputs[i].value != '') {
						s++;
					}
				}
				else if (inputs[i].checked) {
					s++;
				 }
			}
		}

		/*Update the result set*/
		if($scope.items.length == s) {
			for(var j = 0; j < $scope.items.length; j++) {
		   var inputs = document.getElementsByName($scope.items[j].qid);
			 for (var i = 0; i < inputs.length; i++) {
					if($scope.items[j].qtype == 'cloze')	{
						$rootScope.answer.push($sce.trustAsHtml(inputs[i].value));
						var query = "UPDATE questions SET attempts=1, current_choice='"+inputs[i].value+"' WHERE qid="+$scope.items[j].qid;
						var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
						classleConnect.loadLocalData(dbarray,function(data) {
							//alert(JSON.stringify(data));
						},function(data) {
							$rootScope.toast('Something went wrong! Please try again later!');
						});
					}
					else if (inputs[i].checked) {
						$rootScope.answer.push($sce.trustAsHtml(inputs[i].value));
						var query = "UPDATE questions SET attempts=1, current_choice='"+inputs[i].value+"' WHERE qid="+$scope.items[j].qid;
						var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
						classleConnect.loadLocalData(dbarray,function(data) {
							
						},function(data) {
							$rootScope.toast('Something went wrong! Please try again later!');
						});
					 }
				}
			}
			//alert(JSON.stringify($scope.answer));
			$rootScope.showresult = true;
			//$route.reload();
		}
		else {
			$rootScope.toast('Oops! You haven\'t completed the quiz. Please make sure you answer all the questions before submitting.');
		}
	}
}]);

/**
 * course inner offline ends here
/**
 * Inner course ends here
 */

/**
 * Given by Karthick ends here
 */

/**
 * Given by Sekar starts here
 */

/*
 * All Lc Controller
 */
module.controller('onlineAlllCtrl', ['$scope', 'onlinealllc','onlinealllcsearch','onlinesubscribe', '$route','$rootScope', function($scope, onlinealllc, onlinealllcsearch, onlinesubscribe, $route, $rootScope) {
	$scope.items;
	$scope.spinner = true;
	var param = '';
	$scope.searchpart  = '';
	onlinealllc.onlinealllcDetails(param).success(function(data) {
		$scope.pagecount = data.count;
		$scope.items = data;
	}).error(function(data) {
		$rootScope.toast('Something went wrong! Please try again later!');
	});

	$scope.changePage = function(stext) {
		if(stext){
			limit = $scope.currentPage;
			var param = 'type=alllc/&data=' + $scope.data  + '&item=' + $scope.item +'&limit='+limit;
			onlinealllcsearch.onlinealllcsearchDetails(param).success(function(data) {
				$scope.searchpart = data.searchpart;
				$scope.pagecount = data.count;
				$scope.items = data;
			}).error(function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
			});
		}
		else{
			$scope.spinner = true;		
			limit = $scope.currentPage;
			var param = 'limit='+limit;
			onlinealllc.onlinealllcDetails(param).success(function(data) {
				$scope.pagecount = data.count;
				$scope.items = data;
			}).error(function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
			});
		}
	}

	$scope.loadLCS = function(choice,key) {
		var param = 'type=alllc/&data=' + choice + '&item=' + key;
		$scope.type ='alllc/';
		$scope.data = choice;
		$scope.item = key;
		onlinealllcsearch.onlinealllcsearchDetails(param).success(function(data) {
			$scope.searchpart = data.searchpart;
			$scope.pagecount = data.count;
			$scope.items = data;
		}).error(function(data) {
			$rootScope.toast('Something went wrong! Please try again later!');
		});
	}
    
    $scope.ogsubscribe = function(nid){
			var param = 'nodeid='+nid;
			onlinesubscribe.onlinesubscribeDetails(param).success(function(data) {
			$route.reload();
			$scope.items = data;
		}).error(function(data) {
			$rootScope.toast('Something went wrong! Please try again later!');
		});
	}
}]);

/*
 * All Lc Controller
 */
module.controller('onlineMylcCtrl', ['$scope', 'onlinemylc', 'onlinealllcsearch', '$rootScope', function($scope, onlinemylc, onlinealllcsearch, $rootScope) {
	var param = '';
	onlinemylc.onlinemylcDetails(param).success(function(data) {
		$scope.items = data;
		$scope.pagecount = data.count;
	}).error(function(data) {
		$rootScope.toast('Something went wrong! Please try again later!');
	});

	$scope.changePage = function(stext) {
		if(stext){
			limit = $scope.currentPage;
			var param = 'type=mylc/&data=' + $scope.data  + '&item=' + $scope.item +'&limit='+limit;
			onlinealllcsearch.onlinealllcsearchDetails(param).success(function(data) {
				$scope.searchpart = data.searchpart;
				$scope.pagecount = data.count;
				$scope.items = data;
			}).error(function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
			});
		}
		else{
			$scope.spinner = true;		
			limit = $scope.currentPage;
			var param = 'limit='+limit;
			onlinemylc.onlinemylcDetails(param).success(function(data) {
				$scope.pagecount = data.count;
				$scope.items = data;
			}).error(function(data) {
				$rootScope.toast('Something went wrong! Please try again later!');
			});
		}									
	}

	$scope.loadLCS = function(choice,key) {
		var param = 'type=mylc/&data=' + choice + '&item=' + key;
		$scope.type ='mylc/';
		$scope.data = choice;
		$scope.item = key;
		onlinealllcsearch.onlinealllcsearchDetails(param).success(function(data) {
			$scope.searchpart = data.searchpart;
			$scope.pagecount = data.count;
			$scope.items = data;
		}).error(function(data) {
			$rootScope.toast('Something went wrong! Please try again later!');
		});
	}
}]);
/**
 * Course CatlogCtrl starts here
 */
module.value('searchfieldData', {
  searchParam: '',
  searchStatus: false
});

 
module.controller('onlineAllCourseCatlogCtrl', ['$scope', 'onlineAllCourseCatlog', 'searchfieldData', '$rootScope', function($scope, onlineAllCourseCatlog,searchfieldData, $rootScope) {
    $scope.items;
    $scope.pageLimit = 10;
    $scope.spinner = true;
    var param = 'type=allcourse&limit=0';
    var searchtext = '';
    api = 'index/getAllcourse';
    if (searchfieldData.searchStatus) {
   	 param = param + searchfieldData.searchParam;
  	}
  
    $scope.callApi = function(paramData) {
   		 onlineAllCourseCatlog.postAPICall(api, paramData).success(function(data) {
        $scope.items = data;
        $scope.totalItem = data.length;
        $scope.spinner = false;
        searchtext = searchfieldData.searchParam;
      	searchfieldData.searchParam ='';
      	}).error(function(data) {
            $rootScope.toast('Something went wrong! Please try again later!');
      	});
     } 
     $scope.callApi(param);
     $scope.changePage = function() {
      var param = 'type=allcourse&limit=' + $scope.currentPage;
      if (searchfieldData.searchStatus) {
      	param = param + searchtext;
    	}
      $scope.callApi(param);
    }
}]);

/*
 * All Course catlog 
 */
 
 module.controller('onlineMycourseCatlogCtrl', ['$scope', 'onlineMycourseCatlog', 'searchfieldData', '$rootScope', 'classleConnect', function($scope, onlineMycourseCatlog, searchfieldData, $rootScope, classleConnect) {
     if($rootScope.networkStatus){
      $scope.items;
      $scope.pageLimit = 10;
      $scope.spinner = true;
      var searchtext = '';
      var param = 'type=mycourse&limit=0';
      var api = 'index/getAllcourse';
      if (searchfieldData.searchStatus) {
        param = param + searchfieldData.searchParam;
      }

      $scope.callApi = function(paramData) {
        $scope.spinner = true;
        onlineMycourseCatlog.postAPICall(api, paramData).success(function(data) {
          $scope.items = data;
          $scope.totalItem = data.length;
          $scope.spinner = false;
          searchtext = searchfieldData.searchParam;
          searchfieldData.searchParam ='';
        }).error(function(data) {
          $rootScope.toast('Something went wrong! Please try again later!');
        });
      }
      $scope.callApi(param);
      $scope.changePage = function() {
        var param = 'type=mycourse&limit=' + $scope.currentPage;
        if (searchfieldData.searchStatus) {
          param = param + searchtext;
        }
        $scope.callApi(param);
      }
     }
     else{
		var name = 'classledb'; 
		var path = 'default';
		var tableName = 'courses';
		if(searchfieldData.searchStatus){
			var query = "SELECT * FROM courses WHERE name like '%"+	searchfieldData.searchParam +"%'";
		}
		else{
			var query = 'SELECT * FROM courses';
		}
		var dbarray = {'name': name, 'path': path, 'tableName': tableName, 'query': query};
		classleConnect.getlocaldata(dbarray, function(data){ 
		var startdate;
		var enddate;
		var month = new Array();
			month[0] = "Jan";
			month[1] = "Feb";
			month[2] = "Mar";
			month[3] = "Apr";
			month[4] = "May";
			month[5] = "Jun";
			month[6] = "Jul";
			month[7] = "Aug";
			month[8] = "Sep";
			month[9] = "Oct";
			month[10] = "Nov";
			month[11] = "Dec";
		for(var i=0;i<data.row.length;i++){
			 startdate = data.row[i].start_date;
			var start = new Date(startdate*1000);
			var d = start.getDate();
			var m = start.getMonth();
			 data.row[i].start_date = d+','+month[m];
		}
		for(var i=0;i<data.row.length;i++){
			enddate = data.row[i].end_date;
			var end = new Date(enddate*1000);
			var d = end.getDate();
			var m = end.getMonth();
			data.row[i].end_date = d+','+month[m];
		}
		$scope.offlineitems = data.row;
		}, function (data){$rootScope.toast('Something went wrong! Please try again later!');});
 }
 }]);
 

/*
 * Catlog private course
 */
  module.controller('onlinePrivateCatlogctrl', ['$scope', 'onlinePrivateCatlog', 'searchfieldData', '$route','$rootScope', function($scope, onlinePrivateCatlog, searchfieldData, $route, $rootScope) {
    $scope.items;
    $scope.pageLimit = 10;
  	$scope.spinner = true;
  	var param = 'type=private&limit=0';
   	api = 'index/getAllcourse';
   	if (searchfieldData.searchStatus) {
  	  param = param + searchfieldData.searchParam;
  	}
  	$scope.callApi = function(paramData) {
    $scope.spinner = true;
    onlinePrivateCatlog.postAPICall(api, paramData).success(function(data) {
      $scope.items = data;
      $scope.totalItem = data.length;
      searchtext = searchfieldData.searchParam;
      searchfieldData.searchParam ='';
      $scope.spinner = false;
    }).error(function(data) {
      $rootScope.toast('Something went wrong! Please try again later!');
    });
  }
  $scope.callApi(param);
  $scope.changePage = function() {
    var param = 'type=private&limit=' + $scope.currentPage;
    if (searchfieldData.searchStatus) {
      param = param + searchtext;
    }
    $scope.callApi(param);
  }
  
 }]);
 
 
/*
 * Catlog Search
 */
 
 module.controller('onlineCatlogSearchCtrl', ['$scope', 'onlineCatlogSearch', 'searchfieldData', '$route', '$rootScope', function($scope, onlineCatlogSearch, searchfieldData, $route, $rootScope) {
 
 	if($rootScope.networkStatus){	
	 	$scope.subjects;
		$scope.pageLimit = 10;
		$scope.spinner = true;
		var param = 'action=init';
	 	onlineCatlogSearch.postAPICall('index/courseSearch', param).success(function(data) {
    	$scope.subjects = data;
        }).error(function(data) {
            $rootScope.toast('Something went wrong! Please try again later!');
        });
        $scope.doCourseSearch = function() {
              var param = '';
              if ($scope.course_type) {
                param = param + '&course_type=' + $scope.course_type;
              }
              if ($scope.subject) {
                param = param + '&subject=' + $scope.subject;
              }
              if ($scope.duration) {
                param = param + '&duration=' + $scope.duration;
              }
              if ($scope.timeline) {
                param = param + '&timeline=' + $scope.timeline;
              }
              if ($scope.searchText) {
                param = param + '&searchText=' + $scope.searchText;
              }
              searchfieldData.searchParam = param;
              searchfieldData.searchStatus = true;
              $route.reload();
              $scope.spinner = false;
       }
    }
    else{
		$scope.doOfflineCourseSearch = function() {
			var param = '';
	
			if ($scope.searchTextoffline) {
				param = $scope.searchTextoffline;
			}
			searchfieldData.searchParam = param;
			searchfieldData.searchStatus = true;
			$route.reload();
			$scope.spinner = false;
		}
 } 
 }]);
/**
 * Course CatlogCtrl ends here
 */
/**
 * Given by Sekar ends here
 */

module.controller('flipVideoCtrl', ['$scope', 'classleConnect', '$rootScope','$sce', '$routeParams', function($scope, classleConnect, $rootScope, $sce, $routeParams) {
    var nid = $routeParams.flipnid;
    var param = "node="+nid;
    classleConnect.post("course+/courseplus/location/flip",param).success(function(response) {
        var videoLink = response.videolink;
        var type = videoLink.split('.').pop();
        if(type == 'flv')
            type = 'video/flv';
        else 
            type = 'video/mp4';
        var player = '<video id="video1" width="420" controls><source src="'+videoLink+'" type="'+type+'">Your browser does not support HTML5 video.<object type=“application/x-shockwave-flash” data=“flash.swf”><param name=“movie” value=“flash.swf” /><param name=“flashvars” value=“file= video.mp4” /></object></video>';
        $scope.videoplayer = $sce.trustAsHtml(player);
    }).error(function(error){
        $rootScope.toast('Something went wrong! Please try again later!');
    });
    
}]);

/**
 * logout controller
 */
module.controller('logoutCtrl', ['$scope', 'classleConnect', '$rootScope', '$cordovaDialogs','$location','$cordovaFile',function($scope, classleConnect, $rootScope, $cordovaDialogs, $location, $cordovaFile){
    $scope.logout = function() {
        $cordovaDialogs.confirm("Are you sure want to logout?\n\nThis will delete all Synced files!","Logout!", ["Logout", "Cancel"]).then(function(data) {
            if(data == 1) {
                classleConnect.post('newclassle/user/logout', '').success(function(response) {
                    classleConnect.deleteDatabase('classledb', 'default', function(success) {
                        classleConnect.deleteDatabase('userdb', 'default', function(usersuccess) {
                            var sPath = cordova.file.externalRootDirectory;
                            var dataPath = sPath + "com.classle.classlemobile/";
                            $cordovaFile.removeRecursively(dataPath, "files").then(function(success) {
                                $location.path("/home");
                            }, function(error) {
                                $rootScope.toast("Somethig went wrong! Please try agian later.");    
                            })
                        }, function(usererror) {
                            $rootScope.toast("Somethig went wrong! Please try agian later.");
                        });
                    }, function(error) {
                        $rootScope.toast("Somethig went wrong! Please try agian later.");
                    });
                    
                }).error(function(errorresponse) {
                    $rootScope.toast("Somethig went wrong! Please try agian later.");
                });
            }
        }, function(data) {
            alert(data);
        });
    }
}]);
/**
 * forgot password controller
 */

module.controller("forgotpwdCtrl" ,["$scope", "$rootScope", "classleConnect", function($scope, $rootScope, classleConnect) {
    $scope.loader = false;
    $scope.reset = function(mail) {
        $scope.loader = true;
        var param = 'mail='+mail+'&action=reset';
        classleConnect.post('newclassle/classleUser/forgetpassword',param).success(function(success) {
            $scope.loader = false;
            $rootScope.toast(success[0]);
        }).error(function(error) {
            $scope.loader = false;
           $rootScope.toast(error[0]);
        });
    }
}]);