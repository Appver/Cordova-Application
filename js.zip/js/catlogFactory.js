/**
 * RestFull service call
 */
module.factory('onlineAllCourseCatlog', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    postAPICall: function(api, param) {
      var serviceAPi = 'http://test.classle.in/course+/courseplus/';
      return $http.post(serviceAPi + api, param);
    }
  }
}]);

/**
 * RestFull service call
 */
module.factory('onlineMycourseCatlog', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    postAPICall: function(api, param) {
      var serviceAPi = 'http://test.classle.in/course+/courseplus/';
      return $http.post(serviceAPi + api, param);
    }
  }
}]);

/**
 * RestFull service call
 */
module.factory('onlineCatlogSearch', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    postAPICall: function(api, param) {
      var serviceAPi = 'http://test.classle.in/course+/courseplus/';
      return $http.post(serviceAPi + api, param);
    }
  }
}]);

/**
 * RestFull service call
 */
module.factory('onlinePrivateCatlog', ['$http', function($http) {
  $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
  return {
    postAPICall: function(api, param) {
      var serviceAPi = 'http://test.classle.in/course+/courseplus/';
      return $http.post(serviceAPi + api, param);
    }
  }
}]);
